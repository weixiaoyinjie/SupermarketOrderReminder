package com.supermarket.orderreminder;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;

public class AlarmScheduler {
    public static final String PREFS = "order_settings";
    public static final String EXTRA_ID = "entry_id";
    public static final long DAILY = -1;
    private static final int DAILY_REQUEST = 1000000000;

    private static PendingIntent pending(Context c, long id) {
        Intent intent = new Intent(c, ReminderReceiver.class);
        intent.setAction("com.supermarket.orderreminder.ALARM");
        intent.putExtra(EXTRA_ID, id);
        int request = id == DAILY ? DAILY_REQUEST : (int) id;
        return PendingIntent.getBroadcast(c, request, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static long millis(LocalDate date, int minute) {
        return date.atStartOfDay().plusMinutes(minute)
                .atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
    }

    private static void arm(Context c, long id, long timestamp) {
        AlarmManager manager = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (manager == null) return;
        PendingIntent pi = pending(c, id);
        // On Android 12+ exact alarms require the user to grant "Alarms & reminders".
        // If not granted, still schedule a best-effort reminder instead of silently failing.
        if (android.os.Build.VERSION.SDK_INT >= 31 && !manager.canScheduleExactAlarms()) {
            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timestamp, pi);
        } else {
            manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timestamp, pi);
        }
    }

    public static void cancel(Context c, long id) {
        AlarmManager manager = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (manager != null) manager.cancel(pending(c, id));
    }

    public static void scheduleDaily(Context c) {
        cancel(c, DAILY);
        // Fixed at local 09:30 every day, including Sunday.
        int minute = 9 * 60 + 30;
        LocalDate day = LocalDate.now();
        long when = millis(day, minute);
        if (when <= System.currentTimeMillis()) when = millis(day.plusDays(1), minute);
        arm(c, DAILY, when);
    }

    public static void scheduleEntry(Context c, Entry e) {
        cancel(c, e.id);
        if (e.reminderMinute < 0) return;
        LocalDate date;
        if (e.repeatType == 0) {
            try { date = LocalDate.parse(e.date); }
            catch (Exception error) { return; }
        } else {
            int delta = (e.weekday - LocalDate.now().getDayOfWeek().getValue() + 7) % 7;
            date = LocalDate.now().plusDays(delta);
        }
        long when = millis(date, e.reminderMinute);
        if (e.repeatType == 1 && when <= System.currentTimeMillis()) {
            date = date.plusWeeks(1);
            when = millis(date, e.reminderMinute);
        }
        if (when > System.currentTimeMillis()) arm(c, e.id, when);
    }

    public static void scheduleAll(Context c) {
        scheduleDaily(c);
        Db db = new Db(c);
        try {
            List<Entry> entries = db.allEntries();
            for (Entry e : entries) scheduleEntry(c, e);
        } finally { db.close(); }
    }
}
