package com.supermarket.orderreminder;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Db extends SQLiteOpenHelper {
    public static final String FILE = "supermarket_orders.db";

    public Db(Context context) {
        super(context, FILE, null, 1);
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE entries (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, kind INTEGER NOT NULL, repeat_type INTEGER NOT NULL, weekday INTEGER NOT NULL, due_date TEXT NOT NULL DEFAULT '', phone TEXT NOT NULL DEFAULT '', note TEXT NOT NULL DEFAULT '', reminder_minute INTEGER NOT NULL DEFAULT -1)");
        db.execSQL("CREATE TABLE done (entry_id INTEGER NOT NULL, due_date TEXT NOT NULL, PRIMARY KEY(entry_id, due_date))");
        // 周四 14 项初始示例；其他星期一至星期六可自行建立各自的每周循环订货清单。
        String[] thu = {"Molino", "Ruta 9", "Heineken 啤酒", "红酒", "Mendoza 红酒", "Viña Balbo", "Don Angel", "Nestlé", "可乐", "鸡蛋", "Quilmes 啤酒", "Union Paty", "Peñaflor 红酒", "Mitre"};
        for (String title : thu) {
            ContentValues v = new ContentValues();
            v.put("title", title);
            v.put("kind", 0);
            v.put("repeat_type", 1);
            v.put("weekday", 4);
            v.put("due_date", "");
            v.put("phone", "");
            v.put("note", "");
            v.put("reminder_minute", -1);
            db.insertOrThrow("entries", null, v);
        }
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { }

    private Entry fromCursor(Cursor c) {
        Entry e = new Entry();
        e.id = c.getLong(c.getColumnIndexOrThrow("id"));
        e.title = c.getString(c.getColumnIndexOrThrow("title"));
        e.kind = c.getInt(c.getColumnIndexOrThrow("kind"));
        e.repeatType = c.getInt(c.getColumnIndexOrThrow("repeat_type"));
        e.weekday = c.getInt(c.getColumnIndexOrThrow("weekday"));
        e.date = c.getString(c.getColumnIndexOrThrow("due_date"));
        e.phone = c.getString(c.getColumnIndexOrThrow("phone"));
        e.note = c.getString(c.getColumnIndexOrThrow("note"));
        e.reminderMinute = c.getInt(c.getColumnIndexOrThrow("reminder_minute"));
        return e;
    }

    public List<Entry> forDate(LocalDate day) {
        List<Entry> list = new ArrayList<>();
        String date = day.toString();
        String dayOfWeek = Integer.toString(day.getDayOfWeek().getValue());
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT * FROM entries WHERE (repeat_type=0 AND due_date=?) OR (repeat_type=1 AND weekday=?) ORDER BY kind ASC, id ASC",
                new String[]{date, dayOfWeek})) {
            while (c.moveToNext()) list.add(fromCursor(c));
        }
        return list;
    }

    public List<Entry> allEntries() {
        List<Entry> list = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery("SELECT * FROM entries ORDER BY id", null)) {
            while (c.moveToNext()) list.add(fromCursor(c));
        }
        return list;
    }

    public Entry getEntry(long id) {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT * FROM entries WHERE id=?", new String[]{Long.toString(id)})) {
            if (c.moveToFirst()) return fromCursor(c);
        }
        return null;
    }

    public long save(Entry e) {
        ContentValues v = new ContentValues();
        v.put("title", e.title.trim());
        v.put("kind", e.kind);
        v.put("repeat_type", e.repeatType);
        v.put("weekday", e.weekday);
        v.put("due_date", e.repeatType == 0 ? e.date : "");
        v.put("phone", e.phone.trim());
        v.put("note", e.note.trim());
        v.put("reminder_minute", e.reminderMinute);
        if (e.id == 0) e.id = getWritableDatabase().insertOrThrow("entries", null, v);
        else getWritableDatabase().update("entries", v, "id=?", new String[]{Long.toString(e.id)});
        return e.id;
    }

    public void delete(long id) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            db.delete("done", "entry_id=?", new String[]{Long.toString(id)});
            db.delete("entries", "id=?", new String[]{Long.toString(id)});
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    public boolean isDone(long id, String date) {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT 1 FROM done WHERE entry_id=? AND due_date=? LIMIT 1", new String[]{Long.toString(id), date})) {
            return c.moveToFirst();
        }
    }

    public void setDone(long id, String date, boolean done) {
        if (done) {
            ContentValues v = new ContentValues();
            v.put("entry_id", id);
            v.put("due_date", date);
            getWritableDatabase().insertWithOnConflict("done", null, v, SQLiteDatabase.CONFLICT_IGNORE);
        } else {
            getWritableDatabase().delete("done", "entry_id=? AND due_date=?", new String[]{Long.toString(id), date});
        }
    }

    public void resetDay(String date) {
        getWritableDatabase().delete("done", "due_date=?", new String[]{date});
    }

    public JSONObject backup(SharedPreferences prefs) throws JSONException {
        JSONObject root = new JSONObject();
        root.put("format", "supermarket_order_planner");
        root.put("version", 1);
        root.put("daily_enabled", true);
        root.put("daily_minute", 570);
        JSONArray items = new JSONArray();
        for (Entry e : allEntries()) {
            JSONObject o = new JSONObject();
            o.put("id", e.id);
            o.put("title", e.title);
            o.put("kind", e.kind);
            o.put("repeat_type", e.repeatType);
            o.put("weekday", e.weekday);
            o.put("date", e.date);
            o.put("phone", e.phone);
            o.put("note", e.note);
            o.put("reminder_minute", e.reminderMinute);
            items.put(o);
        }
        root.put("entries", items);
        JSONArray checked = new JSONArray();
        try (Cursor c = getReadableDatabase().rawQuery("SELECT entry_id,due_date FROM done", null)) {
            while (c.moveToNext()) {
                JSONObject o = new JSONObject();
                o.put("id", c.getLong(0));
                o.put("date", c.getString(1));
                checked.put(o);
            }
        }
        root.put("done", checked);
        return root;
    }

    public void restore(JSONObject root, SharedPreferences prefs) throws JSONException {
        if (!"supermarket_order_planner".equals(root.optString("format")) || root.optInt("version", 0) != 1) {
            throw new JSONException("不是本应用兼容的备份文件");
        }
        JSONArray items = root.getJSONArray("entries");
        JSONArray checked = root.getJSONArray("done");
        if (items.length() > 10000 || checked.length() > 100000) throw new JSONException("备份记录数量超出限制");
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            db.delete("done", null, null);
            db.delete("entries", null, null);
            for (int i = 0; i < items.length(); i++) {
                JSONObject o = items.getJSONObject(i);
                String title = o.getString("title").trim();
                int kind = o.getInt("kind");
                int repeat = o.getInt("repeat_type");
                int weekday = o.getInt("weekday");
                String date = o.optString("date", "");
                if (title.isEmpty() || title.length() > 200 || kind < 0 || kind > 1 || repeat < 0 || repeat > 1 || weekday < 1 || weekday > 7)
                    throw new JSONException("备份数据包含无效项目");
                if (repeat == 0) LocalDate.parse(date);
                ContentValues v = new ContentValues();
                v.put("id", o.getLong("id"));
                v.put("title", title);
                v.put("kind", kind);
                v.put("repeat_type", repeat);
                v.put("weekday", weekday);
                v.put("due_date", date);
                v.put("phone", o.optString("phone", ""));
                v.put("note", o.optString("note", ""));
                int minute = o.optInt("reminder_minute", -1);
                if (minute < -1 || minute > 1439) throw new JSONException("备份提醒时间无效");
                v.put("reminder_minute", minute);
                db.insertOrThrow("entries", null, v);
            }
            for (int i = 0; i < checked.length(); i++) {
                JSONObject o = checked.getJSONObject(i);
                ContentValues v = new ContentValues();
                v.put("entry_id", o.getLong("id"));
                v.put("due_date", o.getString("date"));
                db.insertWithOnConflict("done", null, v, SQLiteDatabase.CONFLICT_IGNORE);
            }
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
        prefs.edit().putBoolean("daily_enabled", true)
                .putInt("daily_minute", 570).apply();
    }
}
