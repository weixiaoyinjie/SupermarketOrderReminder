package com.supermarket.orderreminder;

public class Entry {
    public long id;
    public String title = "";
    public int kind = 0; // 0=订货, 1=事务
    public int repeatType = 1; // 0=仅指定日期, 1=每周
    public int weekday = 1; // ISO 周一=1..周日=7
    public String date = ""; // yyyy-MM-dd，仅一次性事项使用
    public String phone = "";
    public String note = "";
    public int reminderMinute = -1; // -1=不开单独提醒
}
