package com.supermarket.orderreminder;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.ActivityNotFoundException;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;

/** Offline-first grocery/supermarket purchasing planner. No third party SDK. */
public class MainActivity extends Activity {
    private static final int BG = Color.rgb(10, 14, 20);
    private static final int PANEL = Color.rgb(22, 29, 38);
    private static final int PANEL_2 = Color.rgb(29, 38, 47);
    private static final int WHITE = Color.rgb(245, 249, 251);
    private static final int MUTED = Color.rgb(154, 169, 181);
    private static final int ACCENT = Color.rgb(78, 215, 173);
    private static final int BORDER = Color.rgb(50, 63, 72);
    private static final String[] WEEKDAYS = {"星期一", "星期二", "星期三", "星期四", "星期五", "星期六", "星期日"};
    private static final String[] KINDS = {"订货", "超市事务"};
    private static final int CREATE_BACKUP = 501;
    private static final int OPEN_BACKUP = 502;
    private final DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy年M月d日", Locale.CHINA);
    private Db db;
    private LocalDate selectedDate = LocalDate.now();
    private boolean weekMode = false;
    private ScrollView mainScroll;
    private LinearLayout page;
    private LinearLayout dynamicArea;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        db = new Db(this);
        ReminderReceiver.createChannel(this);
        resolveOpenDate(getIntent());
        setupPage();
        AlarmScheduler.scheduleAll(this);
        askNotificationPermission();
    }

    @Override public void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        resolveOpenDate(intent);
        weekMode = false;
        refresh();
    }

    @Override protected void onResume() {
        super.onResume();
        if (dynamicArea != null) refresh();
    }

    @Override protected void onDestroy() {
        if (db != null) db.close();
        super.onDestroy();
    }

    private void resolveOpenDate(Intent intent) {
        if (intent == null) return;
        String date = intent.getStringExtra("open_date");
        if (date != null) {
            try { selectedDate = LocalDate.parse(date); } catch (Exception ignored) { }
        }
    }

    private int dp(float val) { return Math.round(val * getResources().getDisplayMetrics().density); }

    private GradientDrawable shape(int fill, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radius));
        if (stroke != 0) d.setStroke(dp(1), stroke);
        return d;
    }

    private TextView label(String value, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextColor(color);
        t.setTextSize(size);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button button(String value, boolean primary) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextSize(13);
        b.setTextColor(primary ? BG : WHITE);
        b.setAllCaps(false);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(dp(11), dp(9), dp(11), dp(9));
        b.setBackground(shape(primary ? ACCENT : PANEL_2, primary ? 0 : BORDER, 12));
        return b;
    }

    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout horizontal() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private LinearLayout.LayoutParams margins(int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    private void setupPage() {
        mainScroll = new ScrollView(this);
        mainScroll.setFillViewport(true);
        mainScroll.setBackgroundColor(BG);
        page = vertical();
        page.setPadding(dp(17), dp(18), dp(17), dp(28));
        mainScroll.addView(page, new ScrollView.LayoutParams(-1, -2));
        setContentView(mainScroll);
        dynamicArea = vertical();
        page.addView(dynamicArea, new LinearLayout.LayoutParams(-1, -2));
        refresh();
    }

    private void refresh() {
        if (dynamicArea == null) return;
        int scrollPosition = mainScroll.getScrollY();
        dynamicArea.removeAllViews();
        renderHeader(dynamicArea);
        renderTabs(dynamicArea);
        if (weekMode) renderWeek(dynamicArea);
        else renderDay(dynamicArea, selectedDate, false);
        TextView footer = label("数据只保存在本机 · 每天 09:30 提醒 · 订货按星期循环", 11, MUTED, false);
        footer.setGravity(Gravity.CENTER);
        dynamicArea.addView(footer, margins(-1, -2, 0, 24, 0, 12));
        mainScroll.post(() -> mainScroll.scrollTo(0, scrollPosition));
    }

    private void renderHeader(LinearLayout parent) {
        LinearLayout top = horizontal();
        LinearLayout titleBlock = vertical();
        TextView title = label("超市订货提醒", 24, WHITE, true);
        TextView sub = label("SUPERMARKET  ·  ORDER PLANNER", 11, MUTED, false);
        sub.setLetterSpacing(0.08f);
        titleBlock.addView(title);
        titleBlock.addView(sub, margins(-1, -2, 0, 3, 0, 0));
        top.addView(titleBlock, new LinearLayout.LayoutParams(0, -2, 1));
        Button settings = button("设置", false);
        settings.setOnClickListener(v -> openSettings());
        top.addView(settings, margins(-2, -2, 8, 0, 0, 0));
        parent.addView(top, margins(-1, -2, 0, 0, 0, 18));

        LinearLayout summary = vertical();
        summary.setPadding(dp(17), dp(17), dp(17), dp(17));
        summary.setBackground(shape(PANEL, BORDER, 18));
        LinearLayout line = horizontal();
        line.addView(label(selectedDate.format(dateFormat) + "  " + WEEKDAYS[selectedDate.getDayOfWeek().getValue() - 1],
                18, WHITE, true), new LinearLayout.LayoutParams(0, -2, 1));
        TextView clock = label("09:30", 14, ACCENT, true);
        clock.setPadding(dp(8), dp(5), dp(8), dp(5));
        clock.setBackground(shape(PANEL_2, 0, 9));
        line.addView(clock);
        summary.addView(line);
        int[] cnt = counts(selectedDate);
        TextView stats = label("订货 " + cnt[0] + " 项   ·   事务 " + cnt[1] + " 项   ·   已完成 " + cnt[2] + "/" + (cnt[0] + cnt[1]),
                13, MUTED, false);
        summary.addView(stats, margins(-1, -2, 0, 12, 0, 10));
        int total = cnt[0] + cnt[1];
        View track = new View(this);
        track.setBackground(shape(PANEL_2, 0, 5));
        LinearLayout progress = horizontal();
        progress.setBackground(shape(PANEL_2, 0, 5));
        progress.setClipToOutline(true);
        if (total > 0 && cnt[2] > 0) {
            View fill = new View(this);
            fill.setBackgroundColor(ACCENT);
            progress.addView(fill, new LinearLayout.LayoutParams(0, dp(7), cnt[2]));
        }
        if (total > 0 && cnt[2] < total) {
            progress.addView(new View(this), new LinearLayout.LayoutParams(0, dp(7), total - cnt[2]));
        }
        if (total == 0) progress.addView(track, new LinearLayout.LayoutParams(-1, dp(7)));
        summary.addView(progress, new LinearLayout.LayoutParams(-1, dp(7)));
        parent.addView(summary, margins(-1, -2, 0, 0, 0, 16));
    }

    private int[] counts(LocalDate date) {
        List<Entry> entries = db.forDate(date);
        int[] result = {0, 0, 0};
        for (Entry e : entries) {
            result[e.kind]++;
            if (db.isDone(e.id, date.toString())) result[2]++;
        }
        return result;
    }

    private void renderTabs(LinearLayout parent) {
        LinearLayout modes = horizontal();
        Button today = button("当天清单", !weekMode);
        today.setOnClickListener(v -> { weekMode = false; mainScroll.scrollTo(0, 0); refresh(); });
        modes.addView(today, new LinearLayout.LayoutParams(0, dp(42), 1));
        Button week = button("一周总览", weekMode);
        week.setOnClickListener(v -> { weekMode = true; mainScroll.scrollTo(0, 0); refresh(); });
        modes.addView(week, margins(0, dp(42), 8, 0, 0, 0));
        LinearLayout.LayoutParams second = (LinearLayout.LayoutParams) week.getLayoutParams();
        second.width = 0;
        second.weight = 1;
        week.setLayoutParams(second);
        parent.addView(modes, margins(-1, -2, 0, 0, 0, 13));

        LinearLayout nav = horizontal();
        Button prev = button("‹", false);
        prev.setTextSize(20);
        prev.setOnClickListener(v -> { selectedDate = selectedDate.minusDays(weekMode ? 7 : 1); refresh(); });
        nav.addView(prev);
        Button date = button(weekMode ? "选择所在周 · " + selectedDate.getMonthValue() + "/" + selectedDate.getDayOfMonth()
                : "选择日期 · " + selectedDate.getMonthValue() + "/" + selectedDate.getDayOfMonth(), false);
        date.setOnClickListener(v -> pickDate(selectedDate, d -> { selectedDate = d; refresh(); }));
        nav.addView(date, margins(0, dp(42), 7, 0, 7, 0));
        LinearLayout.LayoutParams dateLp = (LinearLayout.LayoutParams) date.getLayoutParams();
        dateLp.width = 0;
        dateLp.weight = 1;
        date.setLayoutParams(dateLp);
        Button next = button("›", false);
        next.setTextSize(20);
        next.setOnClickListener(v -> { selectedDate = selectedDate.plusDays(weekMode ? 7 : 1); refresh(); });
        nav.addView(next);
        Button backToday = button("今天", false);
        backToday.setOnClickListener(v -> { selectedDate = LocalDate.now(); refresh(); });
        nav.addView(backToday, margins(-2, dp(42), 7, 0, 0, 0));
        parent.addView(nav, margins(-1, -2, 0, 0, 0, 13));
    }

    private void renderDay(LinearLayout parent, LocalDate date, boolean compact) {
        if (!compact) {
            LinearLayout add = horizontal();
            Button order = button("＋ 添加订货", true);
            order.setOnClickListener(v -> editEntry(null, 0, date));
            add.addView(order, new LinearLayout.LayoutParams(0, dp(47), 1));
            Button task = button("＋ 添加事务", false);
            task.setOnClickListener(v -> editEntry(null, 1, date));
            add.addView(task, margins(0, dp(47), 9, 0, 0, 0));
            LinearLayout.LayoutParams taskLp = (LinearLayout.LayoutParams) task.getLayoutParams();
            taskLp.width = 0;
            taskLp.weight = 1;
            task.setLayoutParams(taskLp);
            parent.addView(add, margins(-1, -2, 0, 0, 0, 18));
        }
        List<Entry> entries = db.forDate(date);
        section(parent, date, entries, 0, compact);
        section(parent, date, entries, 1, compact);
        if (!compact) {
            Button reset = button("重置当天全部勾选", false);
            reset.setOnClickListener(v -> new AlertDialog.Builder(this)
                    .setTitle("重置完成记录")
                    .setMessage("确定清除 " + date.format(dateFormat) + " 的所有完成勾选吗？不会删除订货或事务。")
                    .setNegativeButton("取消", null)
                    .setPositiveButton("重置", (d, which) -> { db.resetDay(date.toString()); refresh(); })
                    .show());
            parent.addView(reset, margins(-1, dp(42), 0, 19, 0, 0));
        }
    }

    private void renderWeek(LinearLayout parent) {
        LocalDate monday = selectedDate.minusDays(selectedDate.getDayOfWeek().getValue() - 1);
        TextView title = label(monday.format(dateFormat) + " — " + monday.plusDays(6).format(dateFormat), 14, MUTED, false);
        parent.addView(title, margins(-1, -2, 0, 0, 0, 10));
        for (int day = 0; day < 7; day++) {
            LocalDate date = monday.plusDays(day);
            LinearLayout weekBlock = vertical();
            weekBlock.setPadding(dp(12), dp(12), dp(12), dp(14));
            weekBlock.setBackground(shape(PANEL, BORDER, 16));
            LinearLayout header = horizontal();
            boolean isToday = date.equals(LocalDate.now());
            int[] cnt = counts(date);
            TextView heading = label(WEEKDAYS[day] + "  " + date.getMonthValue() + "月" + date.getDayOfMonth() + "日" +
                    (isToday ? "  · 今天" : ""), 17, isToday ? ACCENT : WHITE, true);
            header.addView(heading, new LinearLayout.LayoutParams(0, -2, 1));
            Button enter = button("打开", false);
            enter.setOnClickListener(v -> { selectedDate = date; weekMode = false; mainScroll.scrollTo(0, 0); refresh(); });
            header.addView(enter);
            weekBlock.addView(header);
            weekBlock.addView(label("已完成 " + cnt[2] + "/" + (cnt[0] + cnt[1]) + "    订货 " + cnt[0] + " · 事务 " + cnt[1],
                    12, MUTED, false), margins(-1, -2, 0, 3, 0, 8));
            List<Entry> entries = db.forDate(date);
            if (entries.isEmpty()) {
                weekBlock.addView(label("暂无安排。点击“打开”可以添加。", 13, MUTED, false));
            } else {
                for (Entry e : entries) weekBlock.addView(itemRow(e, date, true), margins(-1, -2, 0, 3, 0, 3));
            }
            parent.addView(weekBlock, margins(-1, -2, 0, 0, 0, 12));
        }
    }

    private void section(LinearLayout parent, LocalDate date, List<Entry> all, int kind, boolean compact) {
        LinearLayout head = horizontal();
        int count = 0;
        for (Entry e : all) if (e.kind == kind) count++;
        TextView title = label(kind == 0 ? "订货清单" : "超市事务", 18, WHITE, true);
        head.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        head.addView(label(count + " 项", 13, MUTED, false));
        parent.addView(head, margins(-1, -2, 0, kind == 0 ? 0 : 18, 0, 8));
        LinearLayout holder = vertical();
        holder.setPadding(dp(8), dp(7), dp(8), dp(7));
        holder.setBackground(shape(PANEL, BORDER, 16));
        if (count == 0) {
            TextView none = label(kind == 0 ? "这一天还没有订货项目" : "这一天还没有安排事务", 14, MUTED, false);
            none.setPadding(dp(12), dp(18), dp(12), dp(18));
            holder.addView(none);
        } else {
            for (Entry e : all) if (e.kind == kind) holder.addView(itemRow(e, date, compact));
        }
        parent.addView(holder);
    }

    private View itemRow(Entry e, LocalDate date, boolean compact) {
        boolean done = db.isDone(e.id, date.toString());
        LinearLayout row = horizontal();
        row.setPadding(dp(3), dp(compact ? 5 : 9), dp(3), dp(compact ? 5 : 9));
        CheckBox check = new CheckBox(this);
        check.setButtonTintList(ColorStateList.valueOf(ACCENT));
        check.setChecked(done);
        check.setContentDescription("已完成 " + e.title);
        check.setOnCheckedChangeListener((v, checked) -> {
            db.setDone(e.id, date.toString(), checked);
            refresh();
        });
        row.addView(check, margins(dp(42), dp(45), 0, 0, 0, 0));
        LinearLayout information = vertical();
        TextView name = label(e.title, compact ? 14 : 16, done ? MUTED : WHITE, !compact);
        if (done) name.setPaintFlags(name.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        information.addView(name);
        String meta = "";
        if (e.kind == 1 && compact) meta += "事务 · ";
        if (e.repeatType == 0) meta += "单次事项";
        else if (compact) meta += "每周循环";
        if (!e.phone.isEmpty()) meta += (meta.isEmpty() ? "" : "  ·  ") + "WA: " + e.phone;
        if (e.reminderMinute >= 0) meta += (meta.isEmpty() ? "" : "  ·  ") + "提醒 " + minuteLabel(e.reminderMinute);
        if (!meta.isEmpty()) information.addView(label(meta, compact ? 10 : 11, MUTED, false), margins(-1, -2, 0, 2, 0, 0));
        if (!e.note.isEmpty()) information.addView(label(e.note, compact ? 11 : 12, MUTED, false), margins(-1, -2, 0, 3, 0, 0));
        information.setOnClickListener(v -> editEntry(e, e.kind, date));
        row.addView(information, new LinearLayout.LayoutParams(0, -2, 1));
        if (!e.phone.trim().isEmpty()) {
            Button wa = button("WA", true);
            wa.setTextSize(12);
            wa.setOnClickListener(v -> openWhatsApp(e.phone));
            row.addView(wa, margins(-2, dp(36), 5, 0, 4, 0));
        }
        Button edit = button("编辑", false);
        edit.setTextSize(11);
        edit.setOnClickListener(v -> editEntry(e, e.kind, date));
        row.addView(edit, margins(-2, dp(36), 2, 0, 0, 0));
        return row;
    }

    private void openWhatsApp(String phone) {
        String digits = phone.replaceAll("[^0-9]", "");
        if (digits.isEmpty()) { toast("请先编辑并填写 WhatsApp 国际区号和手机号码"); return; }
        Uri uri = Uri.parse("https://wa.me/" + digits);
        for (String pkg : new String[]{"com.whatsapp", "com.whatsapp.w4b"}) {
            Intent i = new Intent(Intent.ACTION_VIEW, uri);
            i.setPackage(pkg);
            try { startActivity(i); return; } catch (Exception ignored) { }
        }
        try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
        catch (ActivityNotFoundException ex) { toast("无法打开 WhatsApp，请检查是否已安装"); }
    }

    private interface DateChoice { void chosen(LocalDate d); }
    private void pickDate(LocalDate initial, DateChoice handler) {
        new DatePickerDialog(this, (view, y, m, d) -> handler.chosen(LocalDate.of(y, m + 1, d)),
                initial.getYear(), initial.getMonthValue() - 1, initial.getDayOfMonth()).show();
    }

    private EditText field(String hint, String value, int inputType) {
        EditText edit = new EditText(this);
        edit.setText(value == null ? "" : value);
        edit.setTextSize(15);
        edit.setTextColor(WHITE);
        edit.setHintTextColor(MUTED);
        edit.setHint(hint);
        edit.setSingleLine(true);
        edit.setInputType(inputType);
        edit.setPadding(dp(9), dp(12), dp(9), dp(12));
        edit.setBackground(shape(PANEL_2, BORDER, 9));
        return edit;
    }

    private void formLabel(LinearLayout parent, String value) {
        parent.addView(label(value, 13, MUTED, true), margins(-1, -2, 0, 14, 0, 5));
    }

    private void editEntry(Entry existing, int initialKind, LocalDate date) {
        Entry e = existing == null ? new Entry() : existing;
        boolean isNew = existing == null;
        final LocalDate[] dueDate = {isNew ? date : (e.repeatType == 0 ? LocalDate.parse(e.date) : date)};
        final int[] separateMinute = {isNew ? -1 : e.reminderMinute};

        ScrollView dialogScroll = new ScrollView(this);
        LinearLayout form = vertical();
        form.setPadding(dp(20), dp(8), dp(20), dp(10));
        dialogScroll.addView(form);
        formLabel(form, "内容名称 *");
        EditText title = field("例如：Nestlé / 去市政府 / 交税", isNew ? "" : e.title, InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        form.addView(title);
        formLabel(form, "类别");
        Spinner kindSpinner = new Spinner(this);
        ArrayAdapter<String> kindAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, KINDS);
        kindSpinner.setAdapter(kindAdapter);
        kindSpinner.setSelection(isNew ? initialKind : e.kind);
        form.addView(kindSpinner);
        formLabel(form, "重复方式");
        RadioGroup freq = new RadioGroup(this);
        freq.setOrientation(LinearLayout.VERTICAL);
        RadioButton weekly = new RadioButton(this);
        weekly.setId(View.generateViewId());
        weekly.setText("每周固定星期循环（适合订货）");
        weekly.setTextColor(WHITE);
        weekly.setButtonTintList(ColorStateList.valueOf(ACCENT));
        RadioButton once = new RadioButton(this);
        once.setId(View.generateViewId());
        once.setText("仅指定日期（适合几天后的事情）");
        once.setTextColor(WHITE);
        once.setButtonTintList(ColorStateList.valueOf(ACCENT));
        freq.addView(weekly);
        freq.addView(once);
        boolean recurring = isNew ? initialKind == 0 : e.repeatType == 1;
        if (recurring) weekly.setChecked(true); else once.setChecked(true);
        form.addView(freq);

        LinearLayout weeklyFields = vertical();
        formLabel(weeklyFields, "每周哪一天");
        Spinner weekPicker = new Spinner(this);
        ArrayAdapter<String> dayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, WEEKDAYS);
        weekPicker.setAdapter(dayAdapter);
        weekPicker.setSelection((isNew ? date.getDayOfWeek().getValue() : e.weekday) - 1);
        weeklyFields.addView(weekPicker);
        form.addView(weeklyFields);

        LinearLayout dateFields = vertical();
        formLabel(dateFields, "计划日期");
        Button dateButton = button(dueDate[0].format(dateFormat) + " · 点击修改日期", false);
        dateButton.setOnClickListener(v -> pickDate(dueDate[0], d -> {
            dueDate[0] = d;
            dateButton.setText(d.format(dateFormat) + " · 点击修改日期");
        }));
        dateFields.addView(dateButton);
        form.addView(dateFields);
        weeklyFields.setVisibility(recurring ? View.VISIBLE : View.GONE);
        dateFields.setVisibility(recurring ? View.GONE : View.VISIBLE);
        freq.setOnCheckedChangeListener((group, checkedId) -> {
            boolean w = checkedId == weekly.getId();
            weeklyFields.setVisibility(w ? View.VISIBLE : View.GONE);
            dateFields.setVisibility(w ? View.GONE : View.VISIBLE);
        });

        formLabel(form, "WhatsApp 号码（可空，带国际区号）");
        EditText phone = field("例如：+54 9 11 1234 5678", isNew ? "" : e.phone, InputType.TYPE_CLASS_PHONE);
        form.addView(phone);
        form.addView(label("填写后，清单会显示 WA 按钮，一键打开对方聊天窗口。", 11, MUTED, false),
                margins(-1, -2, 0, 5, 0, 0));
        formLabel(form, "备注（可空）");
        EditText note = field("订货数量、送货时间或办事说明", isNew ? "" : e.note, InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        note.setSingleLine(false);
        note.setMinLines(2);
        form.addView(note);

        formLabel(form, "该项目单独提醒（可选；每天 09:30 总提醒始终开启）");
        Button reminder = button(separateMinute[0] < 0 ? "不设置单独提醒" : "单独提醒：" + minuteLabel(separateMinute[0]), false);
        reminder.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setItems(new String[]{"设定单独提醒时间", "取消单独提醒"}, (dialog, which) -> {
                    if (which == 1) {
                        separateMinute[0] = -1;
                        reminder.setText("不设置单独提醒");
                    } else {
                        int current = separateMinute[0] < 0 ? 600 : separateMinute[0];
                        new TimePickerDialog(this, (time, hour, minute) -> {
                            separateMinute[0] = hour * 60 + minute;
                            reminder.setText("单独提醒：" + minuteLabel(separateMinute[0]));
                        }, current / 60, current % 60, true).show();
                    }
                }).show());
        form.addView(reminder);

        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setTitle(isNew ? "添加订货 / 事务" : "编辑项目")
                .setView(dialogScroll)
                .setNegativeButton("取消", null)
                .setPositiveButton("保存", null);
        if (!isNew) builder.setNeutralButton("删除", (d, w) -> new AlertDialog.Builder(this)
                .setTitle("删除项目？")
                .setMessage("“" + e.title + "”将被永久删除。若它是每周循环项目，未来所有星期也会一起删除。")
                .setNegativeButton("取消", null)
                .setPositiveButton("确定删除", (d2, w2) -> {
                    AlarmScheduler.cancel(this, e.id);
                    db.delete(e.id);
                    refresh();
                }).show());
        AlertDialog dialog = builder.create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String name = title.getText().toString().trim();
            if (name.isEmpty()) { title.setError("请输入内容名称"); return; }
            if (name.length() > 200) { title.setError("最多 200 字"); return; }
            e.title = name;
            e.kind = kindSpinner.getSelectedItemPosition();
            e.repeatType = weekly.isChecked() ? 1 : 0;
            e.weekday = weekPicker.getSelectedItemPosition() + 1;
            e.date = dueDate[0].toString();
            e.phone = phone.getText().toString().trim();
            e.note = note.getText().toString().trim();
            e.reminderMinute = separateMinute[0];
            if (e.phone.length() > 80 || e.note.length() > 500) {
                toast("号码限 80 字符；备注限 500 字符"); return;
            }
            db.save(e);
            AlarmScheduler.scheduleEntry(this, e);
            dialog.dismiss();
            refresh();
            toast("已保存");
        }));
        dialog.show();
    }

    private String minuteLabel(int minute) { return String.format(Locale.ROOT, "%02d:%02d", minute / 60, minute % 60); }

    private boolean exactAllowed() {
        AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
        return Build.VERSION.SDK_INT < 31 || (am != null && am.canScheduleExactAlarms());
    }

    private boolean notificationAllowed() {
        return Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    }

    private void askNotificationPermission() {
        if (!notificationAllowed() && Build.VERSION.SDK_INT >= 33)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 301);
    }

    private void openSettings() {
        ScrollView sc = new ScrollView(this);
        LinearLayout body = vertical();
        body.setPadding(dp(20), dp(14), dp(20), dp(20));
        sc.addView(body);
        body.addView(label("每天上午 09:30 自动提醒，包括周日。周一至周六的订货会在下周相同星期自动出现。", 15, WHITE, false));
        body.addView(label("通知权限：" + (notificationAllowed() ? "已允许 ✓" : "未允许，需要开启"), 14,
                notificationAllowed() ? ACCENT : WHITE, true), margins(-1, -2, 0, 15, 0, 3));
        body.addView(label("准点闹钟权限：" + (exactAllowed() ? "已允许 ✓" : "未允许，仅能尽力提醒，可能延迟"), 14,
                exactAllowed() ? ACCENT : WHITE, true), margins(-1, -2, 0, 7, 0, 5));
        Button notification = button("开启通知权限", false);
        notification.setOnClickListener(v -> { askNotificationPermission(); if (notificationAllowed()) toast("通知已允许"); });
        body.addView(notification, margins(-1, dp(43), 0, 9, 0, 0));
        Button precise = button("开启准点闹钟权限（重要）", true);
        precise.setOnClickListener(v -> requestExactAlarm());
        body.addView(precise, margins(-1, dp(45), 0, 9, 0, 0));
        Button test = button("发送一条测试通知", false);
        test.setOnClickListener(v -> {
            if (!notificationAllowed()) { askNotificationPermission(); toast("请先允许通知，再测试"); return; }
            ReminderReceiver.show(this, "超市订货提醒测试", "通知正常。每天 09:30 将发送今日清单提醒。", 900200, LocalDate.now());
            toast("已发送测试通知");
        });
        body.addView(test, margins(-1, dp(43), 0, 9, 0, 0));
        Button power = button("打开系统 App 设置（检查电池限制）", false);
        power.setOnClickListener(v -> {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        });
        body.addView(power, margins(-1, dp(43), 0, 9, 0, 0));
        body.addView(label("注意：Android 的省电策略、关机和系统权限可能影响准点通知。启用上面两项权限并允许本应用后台运行。", 12, MUTED, false),
                margins(-1, -2, 0, 10, 0, 5));
        Button export = button("导出全部清单 / 联系人 / 完成记录（JSON）", false);
        export.setOnClickListener(v -> exportBackup());
        body.addView(export, margins(-1, dp(48), 0, 15, 0, 0));
        Button restore = button("导入 JSON 备份（覆盖现有清单）", false);
        restore.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("恢复备份")
                .setMessage("导入将覆盖目前所有订货、号码、事务和完成记录。建议先导出当前清单。")
                .setNegativeButton("取消", null)
                .setPositiveButton("选择备份文件", (d, w) -> importBackup()).show());
        body.addView(restore, margins(-1, dp(45), 0, 9, 0, 0));
        body.addView(label("资料仅储存于此手机。卸载应用可能清除数据，请定期导出备份。", 12, MUTED, false),
                margins(-1, -2, 0, 12, 0, 0));
        new AlertDialog.Builder(this).setTitle("提醒设置与数据备份")
                .setView(sc).setPositiveButton("完成", (d, w) -> {
                    AlarmScheduler.scheduleAll(this);
                    refresh();
                }).show();
    }

    private void requestExactAlarm() {
        if (exactAllowed()) { toast("准点闹钟权限已允许"); return; }
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                        Uri.parse("package:" + getPackageName())));
            } catch (Exception exception) {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:" + getPackageName())));
            }
        }
    }

    private void exportBackup() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        intent.putExtra(Intent.EXTRA_TITLE, "超市订货备份_" + LocalDate.now() + ".json");
        startActivityForResult(intent, CREATE_BACKUP);
    }

    private void importBackup() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(intent, OPEN_BACKUP);
    }

    @Override @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri file = data.getData();
        try {
            if (requestCode == CREATE_BACKUP) {
                JSONObject root = db.backup(getSharedPreferences(AlarmScheduler.PREFS, MODE_PRIVATE));
                try (OutputStream os = getContentResolver().openOutputStream(file)) {
                    if (os == null) throw new Exception("无法写入文件");
                    os.write(root.toString(2).getBytes(StandardCharsets.UTF_8));
                }
                toast("备份已保存");
            } else if (requestCode == OPEN_BACKUP) {
                ByteArrayOutputStream buf = new ByteArrayOutputStream();
                try (InputStream in = getContentResolver().openInputStream(file)) {
                    if (in == null) throw new Exception("无法读取文件");
                    byte[] bytes = new byte[8192];
                    int n;
                    while ((n = in.read(bytes)) >= 0) {
                        if (buf.size() + n > 10 * 1024 * 1024) throw new Exception("备份文件不能超过 10 MB");
                        buf.write(bytes, 0, n);
                    }
                }
                JSONObject root = new JSONObject(new String(buf.toByteArray(), StandardCharsets.UTF_8));
                // Cancel old individual alarms before replacing database entries.
                for (Entry e : db.allEntries()) AlarmScheduler.cancel(this, e.id);
                db.restore(root, getSharedPreferences(AlarmScheduler.PREFS, MODE_PRIVATE));
                AlarmScheduler.scheduleAll(this);
                selectedDate = LocalDate.now();
                refresh();
                toast("备份恢复成功");
            }
        } catch (Exception ex) {
            new AlertDialog.Builder(this).setTitle("操作失败")
                    .setMessage(ex.getMessage() == null ? "无法处理此备份文件" : ex.getMessage())
                    .setPositiveButton("确定", null).show();
        }
    }

    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_LONG).show(); }
}
