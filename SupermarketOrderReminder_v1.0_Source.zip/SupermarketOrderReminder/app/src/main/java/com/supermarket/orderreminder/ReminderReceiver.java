package com.supermarket.orderreminder;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ReminderReceiver extends BroadcastReceiver {
    public static final String CHANNEL_ID = "supermarket_daily_v1";

    public static void createChannel(Context c) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "订货和事务提醒", NotificationManager.IMPORTANCE_DEFAULT);
        channel.setDescription("每天待办与单项指定时间提醒");
        nm.createNotificationChannel(channel);
    }

    private static boolean canNotify(Context c) {
        return Build.VERSION.SDK_INT < 33 || c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    }

    public static void show(Context c, String title, String message, int notificationId, LocalDate date) {
        createChannel(c);
        if (!canNotify(c)) return;
        Intent open = new Intent(c, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        open.putExtra("open_date", date.toString());
        PendingIntent tap = PendingIntent.getActivity(c, notificationId, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification notification = new Notification.Builder(c, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle(title)
                .setContentText(message)
                .setStyle(new Notification.BigTextStyle().bigText(message))
                .setContentIntent(tap)
                .setAutoCancel(true)
                .setCategory(Notification.CATEGORY_REMINDER)
                .build();
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(notificationId, notification);
    }

    @Override public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        long id = intent.getLongExtra(AlarmScheduler.EXTRA_ID, AlarmScheduler.DAILY);
        Db db = new Db(context);
        try {
            LocalDate today = LocalDate.now();
            if (id == AlarmScheduler.DAILY) {
                AlarmScheduler.scheduleDaily(context);
                List<Entry> all = db.forDate(today);
                List<String> pending = new ArrayList<>();
                for (Entry e : all) if (!db.isDone(e.id, today.toString())) pending.add(e.title);
                StringBuilder text;
                if (pending.isEmpty()) {
                    text = new StringBuilder("今天没有待处理项目，可以查看未来的订货和事务。");
                } else {
                    text = new StringBuilder("还有 " + pending.size() + " 项待处理：");
                    for (int i = 0; i < Math.min(pending.size(), 4); i++) {
                        if (i > 0) text.append("、");
                        text.append(pending.get(i));
                    }
                    if (pending.size() > 4) text.append("等");
                }
                show(context, "09:30 · 今日订货 / 超市事务", text.toString(), 100001, today);
            } else {
                Entry e = db.getEntry(id);
                if (e == null) return;
                boolean due = (e.repeatType == 0 && today.toString().equals(e.date))
                        || (e.repeatType == 1 && today.getDayOfWeek().getValue() == e.weekday);
                // 每周项目的下一次提醒必须重新排定。
                if (e.repeatType == 1) AlarmScheduler.scheduleEntry(context, e);
                if (due && !db.isDone(id, today.toString())) {
                    show(context, e.kind == 0 ? "订货提醒：" + e.title : "事务提醒：" + e.title,
                            e.note.isEmpty() ? "点击查看并标记完成" : e.note,
                            (int) (id % 1000000000L) + 100002, today);
                }
            }
        } finally { db.close(); }
    }
}
