package com.supermarket.orderreminder;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;

public class AlarmScheduler {
    public static final String PREFS = "order_settings";
    public static final String EXTRA_ID = "entry_id";
    public static final long DAILY = -1;
    public static final String ACTION_DUE = "com.supermarket.orderreminder.ALARM";
    public static final String ACTION_ADVANCE = "com.supermarket.orderreminder.ALARM_ADVANCE";
    private static final int DAILY_REQUEST = 1000000000;
    private static final int NINE_THIRTY = 570;

    private static PendingIntent pending(Context c, long id, boolean advance) {
        Intent intent = new Intent(c, ReminderReceiver.class);
        intent.setAction(advance ? ACTION_ADVANCE : ACTION_DUE);
        intent.putExtra(EXTRA_ID, id);
        int request = id == DAILY ? DAILY_REQUEST : (int) id;
        return PendingIntent.getBroadcast(c, request, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static long millis(LocalDate date, int minute) {
        return date.atStartOfDay().plusMinutes(minute)
                .atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
    }

    private static void arm(Context c, long id, long timestamp, boolean advance) {
        AlarmManager manager = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (manager == null) return;
        PendingIntent pi = pending(c, id, advance);
        if (android.os.Build.VERSION.SDK_INT >= 31 && !manager.canScheduleExactAlarms()) {
            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timestamp, pi);
        } else {
            manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timestamp, pi);
        }
    }

    public static void cancel(Context c, long id) {
        AlarmManager manager = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (manager != null) {
            manager.cancel(pending(c, id, false));
            if (id != DAILY) manager.cancel(pending(c, id, true));
        }
    }

    public static void scheduleDaily(Context c) {
        cancel(c, DAILY);
        LocalDate day = LocalDate.now();
        long when = millis(day, NINE_THIRTY);
        if (when <= System.currentTimeMillis()) when = millis(day.plusDays(1), NINE_THIRTY);
        arm(c, DAILY, when, false);
    }

    /** Optional individual due-day alert; the shared daily alert continues independently. */
    private static void scheduleDue(Context c, Entry e) {
        if (e.reminderMinute < 0) return;
        LocalDate date;
        if (e.repeatType == 0) {
            try { date = LocalDate.parse(e.date); }
            catch (Exception error) { return; }
        } else if (e.repeatType == 1) {
            int delta = (e.weekday - LocalDate.now().getDayOfWeek().getValue() + 7) % 7;
            date = LocalDate.now().plusDays(delta);
        } else if (e.repeatType == 2) {
            LocalDate now = LocalDate.now();
            date = now.withDayOfMonth(Math.min(e.monthDay, now.lengthOfMonth()));
        } else if (e.repeatType == 4) {
            LocalDate start = LocalDate.now();
            if (e.startDate != null && !e.startDate.isEmpty()) {
                try {
                    LocalDate activated = LocalDate.parse(e.startDate);
                    if (activated.isAfter(start)) start = activated;
                } catch (Exception ignored) { }
            }
            date = WeekdayRules.nextOccurrence(start, e.allowedWeekdays,
                    e.reminderMinute, System.currentTimeMillis());
            if (date == null) return;
        } else return;
        long when = millis(date, e.reminderMinute);
        if (e.repeatType == 1 && when <= System.currentTimeMillis()) {
            date = date.plusWeeks(1);
            when = millis(date, e.reminderMinute);
        } else if (e.repeatType == 2 && when <= System.currentTimeMillis()) {
            LocalDate nextMonth = date.plusMonths(1);
            date = nextMonth.withDayOfMonth(Math.min(e.monthDay, nextMonth.lengthOfMonth()));
            when = millis(date, e.reminderMinute);
        }
        if (when > System.currentTimeMillis()) arm(c, e.id, when, false);
    }

    /** Remind N calendar days ahead at 09:30; match actual occurrence, including month-end. */
    public static void scheduleAdvance(Context c, Entry e) {
        if (e.kind != 1 || e.advanceDays < 1 || e.advanceDays > 365 || e.repeatType == 3) return;
        LocalDate now = LocalDate.now();
        long current = System.currentTimeMillis();
        // One-off errands can be arbitrarily far in the future; schedule their
        // reminder directly instead of relying on a one-year search window.
        if (e.repeatType == 0) {
            try {
                LocalDate remind = LocalDate.parse(e.date).minusDays(e.advanceDays);
                long when = millis(remind, NINE_THIRTY);
                if (when > current && ReminderRules.advanceDueOn(e, remind) != null)
                    arm(c, e.id, when, true);
            } catch (Exception ignored) { }
            return;
        }
        for (int offset = 0; offset <= 370; offset++) {
            LocalDate remind = now.plusDays(offset);
            long when = millis(remind, NINE_THIRTY);
            if (when <= current) continue;
            LocalDate due = ReminderRules.advanceDueOn(e, remind);
            if (due == null) continue;
            arm(c, e.id, when, true);
            return;
        }
    }

    public static void scheduleEntry(Context c, Entry e) {
        cancel(c, e.id);
        scheduleDue(c, e);
        scheduleAdvance(c, e);
    }

    public static void scheduleAll(Context c) {
        scheduleDaily(c);
        Db db = new Db(c);
        try {
            List<Entry> entries = db.allEntries();
            for (Entry e : entries) scheduleEntry(c, e);
        } finally { db.close(); }
    }
}
