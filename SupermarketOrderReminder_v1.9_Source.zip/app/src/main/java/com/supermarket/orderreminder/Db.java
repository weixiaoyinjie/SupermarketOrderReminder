package com.supermarket.orderreminder;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.time.LocalDate;
import java.time.YearMonth;
import java.time.temporal.ChronoUnit;
import java.util.Collections;
import java.util.Comparator;
import java.util.ArrayList;
import java.util.List;

/** Database upgrades preserve all existing user entries, phones, notes and completion records. */
public class Db extends SQLiteOpenHelper {
    public static final String FILE = "supermarket_orders.db";
    private static final int DATABASE_VERSION = 8;

    // Original lists transcribed from the supplied weekday screenshots.
    private static final String[] MONDAY = {
            "牛奶", "酸奶", "Snacks 零食", "Heineken 啤酒", "Perla 面包", "可乐",
            "Quilmes 啤酒", "Peñaflor 红酒", "Fiambre 现成", "Cachifa Tabaco 烟", "Aligol 零食批发商"
    };
    private static final String[] TUESDAY = {
            "Queso Paulina — 奶酪", "Lay's — 薯片", "V Aligol", "La Virgilia", "Rino",
            "Kiosko 次", "狗粮2", "Granix", "红酒 Horniga 女", "Arcor", "7UP 等酒水",
            "Facilita 面包", "烤面包", "老女人突然特价 — 检查啤酒和可乐产品的特价情况"
    };
    private static final String[] WEDNESDAY = {
            "Citric Jugo（果汁）", "Duopack", "牛奶", "酸奶", "Paty", "Manaos（饮料）",
            "袋子", "Torres", "Don Angel Fiam", "BIMBO 面包", "RAICES DEL SUR 面包"
    };
    private static final String[] THURSDAY = {
            "Molino", "Ruta 9", "Heineken 啤酒", "红酒", "Mendoza 红酒", "Viña Balbo",
            "Don Angel", "Nestlé", "可乐", "鸡蛋", "Quilmes 啤酒", "Union Paty", "Peñaflor 红酒", "Mitre"
    };
    private static final String[] FRIDAY = {
            "牛奶", "酸奶", "kiosco 主", "unikard", "潘婷", "terrabusi", "烤面包", "红酒", "中国酱油等产品的外务员"
    };
    private static final String[] SATURDAY = {
            "baggio", "sancor", "dahi酸奶", "Moto Loco酒水"
    };

    public Db(Context context) { super(context, FILE, null, DATABASE_VERSION); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE entries (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, kind INTEGER NOT NULL, repeat_type INTEGER NOT NULL, weekday INTEGER NOT NULL, due_date TEXT NOT NULL DEFAULT '', phone TEXT NOT NULL DEFAULT '', note TEXT NOT NULL DEFAULT '', reminder_minute INTEGER NOT NULL DEFAULT -1, month_day INTEGER NOT NULL DEFAULT 1, start_date TEXT NOT NULL DEFAULT '', allowed_weekdays INTEGER NOT NULL DEFAULT 63, template_id INTEGER NOT NULL DEFAULT 0, advance_days INTEGER NOT NULL DEFAULT 0)");
        db.execSQL("CREATE TABLE done (entry_id INTEGER NOT NULL, due_date TEXT NOT NULL, completed_on TEXT NOT NULL DEFAULT '', PRIMARY KEY(entry_id, due_date))");
        seedDay(db, 1, MONDAY);
        seedDay(db, 2, TUESDAY);
        seedDay(db, 3, WEDNESDAY);
        seedDay(db, 4, THURSDAY);
        seedDay(db, 5, FRIDAY);
        seedDay(db, 6, SATURDAY);
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE entries ADD COLUMN month_day INTEGER NOT NULL DEFAULT 1");
            // Thursday was already supplied by v1. Do not modify it or any existing items.
            seedOtherDays(db);
        }
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE entries ADD COLUMN start_date TEXT NOT NULL DEFAULT ''");
            db.execSQL("ALTER TABLE done ADD COLUMN completed_on TEXT NOT NULL DEFAULT ''");
            ContentValues active = new ContentValues();
            active.put("start_date", LocalDate.now().toString());
            db.update("entries", active, "repeat_type!=0", null);
            db.execSQL("UPDATE done SET completed_on=due_date WHERE completed_on=''");
        }
        if (oldVersion < 4) {
            db.execSQL("ALTER TABLE entries ADD COLUMN allowed_weekdays INTEGER NOT NULL DEFAULT 63");
            db.execSQL("ALTER TABLE entries ADD COLUMN template_id INTEGER NOT NULL DEFAULT 0");
        }
        if (oldVersion < 5) {
            // v1.5 removes all weekday restrictions from on-demand suppliers.
            // Leave existing phone numbers, orders, checks and other fields intact.
            db.execSQL("UPDATE entries SET allowed_weekdays=63 WHERE repeat_type=3");
        }
        if (oldVersion < 7) {
            db.execSQL("ALTER TABLE entries ADD COLUMN advance_days INTEGER NOT NULL DEFAULT 0");
        }
        // v8 expands allowable advance_days values from {0,3} to 0..365,
        // using the same existing column, so no destructive migration is needed.
        // v6 reuses the existing allowed_weekdays integer for selected recurring
        // weekdays (repeat_type=4). Existing daily orders retain 63=Mon-Sat.
        // There is no schema change and no existing data needs rewriting.
    }

    private static void seedOtherDays(SQLiteDatabase db) {
        seedDay(db, 1, MONDAY);
        seedDay(db, 2, TUESDAY);
        seedDay(db, 3, WEDNESDAY);
        seedDay(db, 5, FRIDAY);
        seedDay(db, 6, SATURDAY);
    }

    private static void seedDay(SQLiteDatabase db, int weekday, String[] titles) {
        for (String title : titles) {
            // If the user has already added one of these suppliers, keep their custom version.
            try (Cursor c = db.rawQuery("SELECT 1 FROM entries WHERE kind=0 AND repeat_type=1 AND weekday=? AND title=? LIMIT 1",
                    new String[]{Integer.toString(weekday), title})) {
                if (c.moveToFirst()) continue;
            }
            ContentValues v = new ContentValues();
            v.put("title", title);
            v.put("kind", 0);
            v.put("repeat_type", 1);
            v.put("weekday", weekday);
            v.put("due_date", "");
            v.put("phone", "");
            v.put("note", "");
            v.put("reminder_minute", -1);
            v.put("month_day", 1);
            db.insertOrThrow("entries", null, v);
        }
    }

    private Entry fromCursor(Cursor c) {
        Entry e = new Entry();
        e.id = c.getLong(c.getColumnIndexOrThrow("id"));
        e.title = c.getString(c.getColumnIndexOrThrow("title"));
        e.kind = c.getInt(c.getColumnIndexOrThrow("kind"));
        e.repeatType = c.getInt(c.getColumnIndexOrThrow("repeat_type"));
        e.weekday = c.getInt(c.getColumnIndexOrThrow("weekday"));
        e.date = c.getString(c.getColumnIndexOrThrow("due_date"));
        e.phone = c.getString(c.getColumnIndexOrThrow("phone"));
        e.note = c.getString(c.getColumnIndexOrThrow("note"));
        e.reminderMinute = c.getInt(c.getColumnIndexOrThrow("reminder_minute"));
        e.monthDay = c.getInt(c.getColumnIndexOrThrow("month_day"));
        e.startDate = c.getString(c.getColumnIndexOrThrow("start_date"));
        e.allowedWeekdays = c.getInt(c.getColumnIndexOrThrow("allowed_weekdays"));
        e.templateId = c.getLong(c.getColumnIndexOrThrow("template_id"));
        e.advanceDays = c.getInt(c.getColumnIndexOrThrow("advance_days"));
        return e;
    }

    /** A 29/30/31 monthly task falls on the month's last day in shorter months. */
    public static boolean occursOn(Entry e, LocalDate date) {
        return TaskAdvanceRules.occursOn(e, date);
    }

    public List<Entry> forDate(LocalDate day) {
        List<Entry> list = new ArrayList<>();
        String d = Integer.toString(day.getDayOfMonth());
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT * FROM entries WHERE (repeat_type=0 AND due_date=?) " +
                        "OR (repeat_type=1 AND weekday=?) " +
                        "OR (repeat_type=2 AND (month_day=? OR (month_day>? AND ?=?))) " +
                        "OR (repeat_type=4 AND (allowed_weekdays & ?) != 0 AND (start_date='' OR start_date<=?)) " +
                        "ORDER BY kind ASC, id ASC",
                new String[]{day.toString(), Integer.toString(day.getDayOfWeek().getValue()), d,
                        Integer.toString(day.lengthOfMonth()), d, Integer.toString(day.lengthOfMonth()),
                        Integer.toString(WeekdayRules.bitForIsoDay(day.getDayOfWeek().getValue())), day.toString()})) {
            while (c.moveToNext()) list.add(fromCursor(c));
        }
        return list;
    }

    public List<Entry> allEntries() {
        List<Entry> list = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery("SELECT * FROM entries ORDER BY id", null)) {
            while (c.moveToNext()) list.add(fromCursor(c));
        }
        return list;
    }

    public Entry getEntry(long id) {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT * FROM entries WHERE id=?", new String[]{Long.toString(id)})) {
            if (c.moveToFirst()) return fromCursor(c);
        }
        return null;
    }

    public long save(Entry e) {
        ContentValues v = new ContentValues();
        v.put("title", e.title.trim());
        v.put("kind", e.kind);
        v.put("repeat_type", e.repeatType);
        v.put("weekday", e.weekday);
        v.put("due_date", e.repeatType == 0 ? e.date : "");
        v.put("phone", e.phone.trim());
        v.put("note", e.note.trim());
        v.put("reminder_minute", e.reminderMinute);
        v.put("month_day", e.monthDay);
        v.put("allowed_weekdays", e.allowedWeekdays);
        v.put("template_id", e.templateId);
        v.put("advance_days", e.kind == 1 ? e.advanceDays : 0);
        if (e.startDate == null || e.startDate.isEmpty()) e.startDate = LocalDate.now().toString();
        v.put("start_date", e.startDate);
        if (e.id == 0) e.id = getWritableDatabase().insertOrThrow("entries", null, v);
        else getWritableDatabase().update("entries", v, "id=?", new String[]{Long.toString(e.id)});
        return e.id;
    }

    /** Only templates are listed here: they never enter daily schedules by themselves. */
    public List<Entry> demandTemplates() {
        List<Entry> list = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT * FROM entries WHERE kind=0 AND repeat_type=3 ORDER BY title COLLATE NOCASE, id", null)) {
            while (c.moveToNext()) list.add(fromCursor(c));
        }
        return list;
    }

    /** On-demand suppliers can be ordered on ANY calendar day, including Sunday. */
    public static boolean isAllowedDay(Entry template, LocalDate day) {
        return template != null && template.kind == 0 && template.repeatType == 3 && day != null;
    }

    public static class DemandAddResult {
        public final Entry order;
        public final boolean created;
        DemandAddResult(Entry order, boolean created) { this.order = order; this.created = created; }
    }

    /** Add exactly one occurrence. The master template stays outside the daily list. */
    public DemandAddResult addDemandOrder(Entry template, LocalDate day) {
        if (template == null || template.id <= 0 || template.repeatType != 3 || template.kind != 0 || day == null)
            throw new IllegalArgumentException("不是有效的按需订货项目");
        if (day.isBefore(LocalDate.now()))
            throw new IllegalArgumentException("不能安排到过去的日期");
        SQLiteDatabase database = getWritableDatabase();
        database.beginTransaction();
        try {
            try (Cursor c = database.rawQuery(
                    "SELECT id FROM entries WHERE template_id=? AND repeat_type=0 AND due_date=? LIMIT 1",
                    new String[]{Long.toString(template.id), day.toString()})) {
                if (c.moveToFirst()) {
                    Entry existing = getEntry(c.getLong(0));
                    database.setTransactionSuccessful();
                    return new DemandAddResult(existing, false);
                }
            }
            Entry order = new Entry();
            order.title = template.title;
            order.kind = 0;
            order.repeatType = 0;
            order.date = day.toString();
            order.weekday = day.getDayOfWeek().getValue();
            order.monthDay = day.getDayOfMonth();
            order.allowedWeekdays = template.allowedWeekdays;
            order.templateId = template.id;
            order.phone = template.phone;
            order.note = template.note;
            order.reminderMinute = template.reminderMinute;
            order.startDate = LocalDate.now().toString();
            save(order);
            database.setTransactionSuccessful();
            return new DemandAddResult(order, true);
        } finally { database.endTransaction(); }
    }

    public void delete(long id) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            db.delete("done", "entry_id=?", new String[]{Long.toString(id)});
            db.delete("entries", "id=?", new String[]{Long.toString(id)});
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    public boolean isDone(long id, String date) {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT 1 FROM done WHERE entry_id=? AND due_date=? LIMIT 1", new String[]{Long.toString(id), date})) {
            return c.moveToFirst();
        }
    }

    public void setDone(long id, String date, boolean done) {
        setDone(id, date, done, date);
    }

    /** Late completion uses the ORIGINAL due date as the recurring occurrence key. */
    public void setDone(long id, String date, boolean done, String completedOn) {
        if (done) {
            ContentValues v = new ContentValues();
            v.put("entry_id", id);
            v.put("due_date", date);
            v.put("completed_on", completedOn);
            getWritableDatabase().insertWithOnConflict("done", null, v, SQLiteDatabase.CONFLICT_REPLACE);
        } else {
            getWritableDatabase().delete("done", "entry_id=? AND due_date=?", new String[]{Long.toString(id), date});
        }
    }

    public boolean wasCompletedOn(long id, String dueDate, String completedOn) {
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT 1 FROM done WHERE entry_id=? AND due_date=? AND completed_on=? LIMIT 1",
                new String[]{Long.toString(id), dueDate, completedOn})) {
            return c.moveToFirst();
        }
    }

    public static class TaskOccurrence {
        public final Entry entry;
        public final LocalDate dueDate;
        public final boolean completed;
        public TaskOccurrence(Entry e, LocalDate dueDate, boolean completed) {
            this.entry = e;
            this.dueDate = dueDate;
            this.completed = completed;
        }
    }

    /**
     * Today's tasks plus outstanding overdue tasks. Repeating tasks never create
     * overdue instances before the day the user added/restored them.
     * We show up to one year's monthly cycles / eight weeks of weekly cycles to
     * prevent an unbounded number of stale reminders on small screens.
     */
    public List<TaskOccurrence> tasksForDate(LocalDate today) {
        List<TaskOccurrence> result = new ArrayList<>();
        for (Entry e : allEntries()) {
            if (e.kind != 1) continue;
            LocalDate active;
            try { active = e.startDate.isEmpty() ? today : LocalDate.parse(e.startDate); }
            catch (Exception bad) { active = today; }
            if (e.repeatType == 0) {
                try { addTaskOccurrence(result, e, LocalDate.parse(e.date), today); }
                catch (Exception ignored) { }
            } else if (e.repeatType == 1) {
                // Weekly tasks: only consider occurrences from the day they were created.
                LocalDate start = today.minusDays(56);
                if (active.isAfter(start)) start = active;
                int offset = (e.weekday - start.getDayOfWeek().getValue() + 7) % 7;
                for (LocalDate d = start.plusDays(offset); !d.isAfter(today); d = d.plusWeeks(1))
                    addTaskOccurrence(result, e, d, today);
            } else if (e.repeatType == 2) {
                LocalDate start = today.minusMonths(12).withDayOfMonth(1);
                if (active.isAfter(start)) start = active;
                for (YearMonth month = YearMonth.from(start); !month.isAfter(YearMonth.from(today)); month = month.plusMonths(1)) {
                    LocalDate due = month.atDay(Math.min(e.monthDay, month.lengthOfMonth()));
                    if (!due.isBefore(active)) addTaskOccurrence(result, e, due, today);
                }
            }
        }
        Collections.sort(result, (a, b) -> {
            boolean ao = a.dueDate.isBefore(today);
            boolean bo = b.dueDate.isBefore(today);
            if (ao != bo) return ao ? -1 : 1;
            int c = a.dueDate.compareTo(b.dueDate);
            return c != 0 ? c : Long.compare(a.entry.id, b.entry.id);
        });
        return result;
    }

    private void addTaskOccurrence(List<TaskOccurrence> results, Entry e, LocalDate due, LocalDate viewingDate) {
        if (due.isAfter(viewingDate)) return;
        boolean checked = isDone(e.id, due.toString());
        // Current-day tasks are always shown, even when checked. A task finished
        // late remains visible with a tick on its completion day.
        if (due.equals(viewingDate) || !checked || wasCompletedOn(e.id, due.toString(), viewingDate.toString()))
            results.add(new TaskOccurrence(e, due, checked));
    }

    /** Future notices are informational, not due or overdue tasks. */
    public List<TaskOccurrence> advanceTasksForDate(LocalDate viewingDate) {
        List<TaskOccurrence> result = new ArrayList<>();
        for (Entry e : allEntries()) {
            if (!TaskAdvanceRules.alertDaysAhead(e, viewingDate)) continue;
            LocalDate due = viewingDate.plusDays(e.advanceDays);
            if (!isDone(e.id, due.toString())) result.add(new TaskOccurrence(e, due, false));
        }
        return result;
    }

    public void resetDay(String date) {
        getWritableDatabase().delete("done", "due_date=? OR completed_on=?", new String[]{date, date});
    }

    public JSONObject backup(SharedPreferences prefs) throws JSONException {
        JSONObject root = new JSONObject();
        root.put("format", "supermarket_order_planner");
        root.put("version", 8);
        root.put("daily_enabled", true);
        root.put("daily_minute", 570);
        JSONArray items = new JSONArray();
        for (Entry e : allEntries()) {
            JSONObject o = new JSONObject();
            o.put("id", e.id);
            o.put("title", e.title);
            o.put("kind", e.kind);
            o.put("repeat_type", e.repeatType);
            o.put("weekday", e.weekday);
            o.put("date", e.date);
            o.put("phone", e.phone);
            o.put("note", e.note);
            o.put("reminder_minute", e.reminderMinute);
            o.put("month_day", e.monthDay);
            o.put("start_date", e.startDate);
            o.put("allowed_weekdays", e.allowedWeekdays);
            o.put("template_id", e.templateId);
            o.put("advance_days", e.kind == 1 ? e.advanceDays : 0);
            items.put(o);
        }
        root.put("entries", items);
        JSONArray checked = new JSONArray();
        try (Cursor c = getReadableDatabase().rawQuery("SELECT entry_id,due_date,completed_on FROM done", null)) {
            while (c.moveToNext()) {
                JSONObject o = new JSONObject();
                o.put("id", c.getLong(0));
                o.put("date", c.getString(1));
                o.put("completed_on", c.getString(2));
                checked.put(o);
            }
        }
        root.put("done", checked);
        return root;
    }

    public void restore(JSONObject root, SharedPreferences prefs) throws JSONException {
        int version = root.optInt("version", 0);
        if (!"supermarket_order_planner".equals(root.optString("format")) || (version < 1 || version > 8)) {
            throw new JSONException("不是本应用兼容的备份文件");
        }
        JSONArray items = root.getJSONArray("entries");
        JSONArray checked = root.getJSONArray("done");
        if (items.length() > 10000 || checked.length() > 100000) throw new JSONException("备份记录数量超出限制");
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            db.delete("done", null, null);
            db.delete("entries", null, null);
            for (int i = 0; i < items.length(); i++) {
                JSONObject o = items.getJSONObject(i);
                String title = o.getString("title").trim();
                int kind = o.getInt("kind");
                int repeat = o.getInt("repeat_type");
                int weekday = o.getInt("weekday");
                int monthDay = o.optInt("month_day", 1);
                int allowed = o.optInt("allowed_weekdays", 63);
                long templateId = o.optLong("template_id", 0);
                String date = o.optString("date", "");
                if (title.isEmpty() || title.length() > 200 || kind < 0 || kind > 1 || repeat < 0 || repeat > 4 || weekday < 1 || weekday > 7 || monthDay < 1 || monthDay > 31 || allowed < 1 || allowed > 127 || templateId < 0 || ((repeat == 3 || repeat == 4) && kind != 0))
                    throw new JSONException("备份数据包含无效项目");
                if (repeat == 0) {
                    try { LocalDate.parse(date); }
                    catch (Exception error) { throw new JSONException("备份日期无效"); }
                }
                ContentValues v = new ContentValues();
                v.put("id", o.getLong("id"));
                v.put("title", title);
                v.put("kind", kind);
                v.put("repeat_type", repeat);
                v.put("weekday", weekday);
                v.put("due_date", repeat == 0 ? date : "");
                v.put("phone", o.optString("phone", ""));
                v.put("note", o.optString("note", ""));
                int minute = o.optInt("reminder_minute", -1);
                if (minute < -1 || minute > 1439) throw new JSONException("备份提醒时间无效");
                v.put("reminder_minute", minute);
                v.put("month_day", monthDay);
                // An old v4 backup may have weekday-restricted demand templates:
                // v1.5 makes them available on any day without losing other details.
                v.put("allowed_weekdays", repeat == 3 ? 63 : allowed);
                v.put("template_id", templateId);
                int advance = o.optInt("advance_days", 0);
                if (advance < 0 || advance > 365) throw new JSONException("提前提醒天数必须为0至365天");
                v.put("advance_days", kind == 1 ? advance : 0);
                // Legacy backup has no activation date: don't invent previous unpaid cycles.
                String activeDate = o.optString("start_date", "");
                try { if (!activeDate.isEmpty()) LocalDate.parse(activeDate); }
                catch (Exception ex) { throw new JSONException("循环开始日期无效"); }
                v.put("start_date", activeDate.isEmpty() ? LocalDate.now().toString() : activeDate);
                db.insertOrThrow("entries", null, v);
            }
            for (int i = 0; i < checked.length(); i++) {
                JSONObject o = checked.getJSONObject(i);
                ContentValues v = new ContentValues();
                v.put("entry_id", o.getLong("id"));
                v.put("due_date", o.getString("date"));
                v.put("completed_on", o.optString("completed_on", o.getString("date")));
                db.insertWithOnConflict("done", null, v, SQLiteDatabase.CONFLICT_IGNORE);
            }
            // Restoring a v1 backup must not remove the new Mon/Tue/Wed/Fri/Sat lists.
            // v2 backups are left exactly as saved (including user deletions).
            if (version == 1) seedOtherDays(db);
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
        prefs.edit().putBoolean("daily_enabled", true).putInt("daily_minute", 570).apply();
    }
}
