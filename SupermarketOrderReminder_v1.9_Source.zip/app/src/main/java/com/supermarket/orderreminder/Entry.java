package com.supermarket.orderreminder;

public class Entry {
    public long id;
    public String title = "";
    public int kind = 0; // 0=订货, 1=事务
    public int repeatType = 1; // 0=单次, 1=每周, 2=每月, 3=按需货品模板, 4=自选星期自动循环（默认周一至周六）
    public int weekday = 1; // ISO 周一=1..周日=7
    public int allowedWeekdays = 63; // repeatType=4 的周一..周日 7 位掩码，默认 63=周一至周六；按需类型不限制星期
    public long templateId = 0; // 从哪个按需货品库模板安排的单次订货
    public int monthDay = 1; // 每月 1..31；短月份自动取当月最后一天
    public String date = ""; // yyyy-MM-dd，仅一次性事项使用
    public String startDate = ""; // recurring event activation date; prevents pre-creation overdue alerts
    public String phone = "";
    public String note = "";
    public int reminderMinute = -1; // -1=不开单独提醒
    public int advanceDays = 0; // 事务选填：0=只在当天09:30，1..365=提前N天+当天09:30
}
