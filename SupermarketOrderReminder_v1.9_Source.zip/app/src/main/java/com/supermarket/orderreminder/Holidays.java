package com.supermarket.orderreminder;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

/** Argentina national holiday data, cached by year for offline display. */
public final class Holidays {
    private Holidays() {}
    private static final String PREFS = "argentina_holidays_cache";
    private static final long ONE_DAY = 24L * 60L * 60L * 1000L;
    private static final Set<Integer> IN_FLIGHT = new HashSet<>();

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static String notice(Context c, LocalDate day) {
        String current = holidayOn(c, day);
        String next = holidayOn(c, day.plusDays(7));
        StringBuilder b = new StringBuilder();
        if (!current.isEmpty()) b.append("今日阿根廷节日：").append(current);
        if (!next.isEmpty()) {
            if (b.length() > 0) b.append(" · ");
            b.append("7天后节日：").append(next);
        }
        return b.toString();
    }

    private static String holidayOn(Context c, LocalDate d) {
        String data = prefs(c).getString("year_" + d.getYear(), "");
        if (data.isEmpty()) return "";
        try {
            JSONArray arr = new JSONArray(data);
            StringBuilder out = new StringBuilder();
            for (int i = 0; i < arr.length(); i++) {
                JSONObject holiday = arr.optJSONObject(i);
                if (holiday == null || !d.toString().equals(holiday.optString("date"))) continue;
                if (out.length() > 0) out.append("、");
                out.append(holiday.optString("name"));
            }
            return out.toString();
        } catch (Exception ignored) { return ""; }
    }

    public static void ensureLoaded(Context c, LocalDate day, Runnable refreshUi) {
        loadYear(c, day.getYear(), refreshUi);
        if (day.plusDays(7).getYear() != day.getYear())
            loadYear(c, day.plusDays(7).getYear(), refreshUi);
    }

    private static void loadYear(Context c, int year, Runnable refreshUi) {
        SharedPreferences store = prefs(c);
        long now = System.currentTimeMillis();
        if (now - store.getLong("checked_" + year, 0) < ONE_DAY) return;
        if (now - store.getLong("failed_" + year, 0) < 60L * 60L * 1000L) return;
        synchronized (IN_FLIGHT) {
            if (!IN_FLIGHT.add(year)) return;
        }
        Context app = c.getApplicationContext();
        new Thread(() -> {
            try {
                JSONArray holidays = fetch(year);
                if (holidays.length() == 0) throw new IllegalStateException("No national holidays returned");
                prefs(app).edit().putString("year_" + year, holidays.toString())
                        .putLong("checked_" + year, System.currentTimeMillis())
                        .remove("failed_" + year).apply();
                if (refreshUi != null)
                    new Handler(Looper.getMainLooper()).post(refreshUi);
            } catch (Exception ex) {
                prefs(app).edit().putLong("failed_" + year, System.currentTimeMillis()).apply();
            } finally {
                synchronized (IN_FLIGHT) { IN_FLIGHT.remove(year); }
            }
        }, "HolidayFetch-" + year).start();
    }

    private static JSONArray fetch(int year) throws Exception {
        if (year <= 2026 && year >= 2016) {
            try {
                JSONArray input = new JSONArray(get("https://api.argentinadatos.com/v1/feriados/" + year));
                JSONArray output = new JSONArray();
                for (int i=0; i<input.length(); i++) {
                    JSONObject h = input.optJSONObject(i);
                    if (h == null || h.optString("fecha").isEmpty() || h.optString("nombre").isEmpty()) continue;
                    JSONObject row = new JSONObject();
                    row.put("date", h.optString("fecha"));
                    row.put("name", h.optString("nombre"));
                    output.put(row);
                }
                if (output.length() > 0) return output;
            } catch (Exception ignored) { /* Use the secondary public holiday API. */ }
        }
        // Nager v4 is the supported public API for future years (v3 retires in 2027).
        JSONArray input = new JSONArray(get("https://nagerholidays.com/api/v4/Holidays/AR/" + year));
        JSONArray output = new JSONArray();
        for (int i=0; i<input.length(); i++) {
            JSONObject h = input.optJSONObject(i);
            if (h == null || h.optString("date").isEmpty()) continue;
            if (!h.optBoolean("nationalHoliday", false)) continue;
            JSONArray types = h.optJSONArray("holidayTypes");
            boolean isPublic = false;
            if (types != null) for (int j=0; j<types.length(); j++)
                if ("Public".equals(types.optString(j))) isPublic = true;
            if (!isPublic) continue;
            JSONObject row = new JSONObject();
            row.put("date", h.optString("date"));
            row.put("name", h.optString("name"));
            output.put(row);
        }
        return output;
    }

    private static String get(String url) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
        connection.setConnectTimeout(4000);
        connection.setReadTimeout(5000);
        connection.setRequestProperty("Accept", "application/json");
        connection.setInstanceFollowRedirects(true);
        try {
            if (connection.getResponseCode() != 200) throw new IllegalStateException("Holiday API HTTP " + connection.getResponseCode());
            try (InputStream in = connection.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[4096];
                int n;
                while ((n = in.read(buffer)) != -1) {
                    if (out.size() + n > 500000) throw new IllegalStateException("Holiday payload too large");
                    out.write(buffer, 0, n);
                }
                return out.toString(StandardCharsets.UTF_8.name());
            }
        } finally { connection.disconnect(); }
    }
}
