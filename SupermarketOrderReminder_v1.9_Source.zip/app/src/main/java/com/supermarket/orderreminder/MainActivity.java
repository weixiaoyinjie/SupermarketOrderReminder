package com.supermarket.orderreminder;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.ActivityNotFoundException;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextUtils.TruncateAt;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.AdapterView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;

/** Offline-first grocery/supermarket purchasing planner. No third party SDK. */
public class MainActivity extends Activity {
    private static final int BG = Color.rgb(10, 14, 20);
    private static final int PANEL = Color.rgb(22, 29, 38);
    private static final int PANEL_2 = Color.rgb(29, 38, 47);
    private static final int WHITE = Color.rgb(245, 249, 251);
    private static final int MUTED = Color.rgb(154, 169, 181);
    private static final int ACCENT = Color.rgb(78, 215, 173);
    private static final int BORDER = Color.rgb(50, 63, 72);
    private static final int OVERDUE = Color.rgb(251, 180, 100);
    private static final String[] WEEKDAYS = {"星期一", "星期二", "星期三", "星期四", "星期五", "星期六", "星期日"};
    private static final String[] KINDS = {"订货", "超市事务"};
    private static final int CREATE_BACKUP = 501;
    private static final int OPEN_BACKUP = 502;
    private final DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy年M月d日", Locale.CHINA);
    private Db db;
    private LocalDate selectedDate = LocalDate.now();
    private boolean weekMode = false;
    /** Compact ordering list by default; toolbar stays folded until requested. */
    private boolean controlsExpanded = false;
    private boolean compactList = true;
    private ScrollView mainScroll;
    private LinearLayout page;
    private LinearLayout dynamicArea;
    private AlertDialog activeDemandDialog;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        db = new Db(this);
        ReminderReceiver.createChannel(this);
        resolveOpenDate(getIntent());
        setupPage();
        AlarmScheduler.scheduleAll(this);
        askNotificationPermission();
    }

    @Override public void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        resolveOpenDate(intent);
        weekMode = false;
        controlsExpanded = false;
        refresh();
    }

    @Override protected void onResume() {
        super.onResume();
        if (dynamicArea != null) refresh();
    }

    @Override protected void onDestroy() {
        if (db != null) db.close();
        super.onDestroy();
    }

    private void resolveOpenDate(Intent intent) {
        if (intent == null) return;
        String date = intent.getStringExtra("open_date");
        if (date != null) {
            try { selectedDate = LocalDate.parse(date); } catch (Exception ignored) { }
        }
    }

    private int dp(float val) { return Math.round(val * getResources().getDisplayMetrics().density); }

    private GradientDrawable shape(int fill, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radius));
        if (stroke != 0) d.setStroke(dp(1), stroke);
        return d;
    }

    private TextView label(String value, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextColor(color);
        t.setTextSize(size);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button button(String value, boolean primary) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextSize(13);
        b.setTextColor(primary ? BG : WHITE);
        b.setAllCaps(false);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(dp(11), dp(9), dp(11), dp(9));
        b.setBackground(shape(primary ? ACCENT : PANEL_2, primary ? 0 : BORDER, 12));
        return b;
    }

    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout horizontal() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private LinearLayout.LayoutParams margins(int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    private void setupPage() {
        mainScroll = new ScrollView(this);
        mainScroll.setFillViewport(true);
        mainScroll.setBackgroundColor(BG);
        page = vertical();
        page.setPadding(dp(14), dp(9), dp(14), dp(8));
        mainScroll.addView(page, new ScrollView.LayoutParams(-1, -2));
        setContentView(mainScroll);
        dynamicArea = vertical();
        page.addView(dynamicArea, new LinearLayout.LayoutParams(-1, -2));
        refresh();
    }

    private void refresh() {
        if (dynamicArea == null) return;
        int scrollPosition = mainScroll.getScrollY();
        dynamicArea.removeAllViews();
        Holidays.ensureLoaded(this, LocalDate.now(), () -> { if (!isFinishing()) refresh(); });
        Holidays.ensureLoaded(this, selectedDate, () -> { if (!isFinishing()) refresh(); });
        // Prefetch next year for December -> January's seven-day warnings.
        Holidays.ensureLoaded(this, LocalDate.of(LocalDate.now().getYear() + 1, 1, 1),
                () -> { if (!isFinishing()) refresh(); });
        renderHeader(dynamicArea);
        if (controlsExpanded) renderTabs(dynamicArea);
        if (weekMode) renderWeek(dynamicArea);
        else renderDay(dynamicArea, selectedDate, false);
        // In folded daily mode the entire vertical area belongs to the checklist.
        if (controlsExpanded || weekMode) {
            TextView footer = label("订货/事务仅存本机 · 09:30 提醒 · 节日联网同步并缓存", 11, MUTED, false);
            footer.setGravity(Gravity.CENTER);
            dynamicArea.addView(footer, margins(-1, -2, 0, 14, 0, 8));
        }
        mainScroll.post(() -> mainScroll.scrollTo(0, scrollPosition));
    }

    /** Always-visible header: date, weekday and the compact toggle only. */
    private void renderHeader(LinearLayout parent) {
        LinearLayout summary = vertical();
        summary.setPadding(dp(10), dp(5), dp(9), dp(5));
        summary.setBackground(shape(PANEL, BORDER, 13));
        LinearLayout line = horizontal();
        LinearLayout dateColumn = vertical();
        TextView dateTitle = label(selectedDate.format(dateFormat) + "  " +
                WEEKDAYS[selectedDate.getDayOfWeek().getValue() - 1], 15, WHITE, true);
        dateTitle.setSingleLine(true);
        dateTitle.setEllipsize(TruncateAt.END);
        dateColumn.addView(dateTitle);
        String holidayNotice = Holidays.notice(this, selectedDate);
        if (!holidayNotice.isEmpty()) {
            TextView holidayTag = label(holidayNotice, 11, OVERDUE, false);
            holidayTag.setMaxLines(2);
            dateColumn.addView(holidayTag, margins(-1, -2, 0, 2, 0, 0));
        }
        dateColumn.setOnClickListener(v -> pickDate(selectedDate, d -> {
            selectedDate = d;
            weekMode = false;
            refresh();
            mainScroll.post(() -> mainScroll.scrollTo(0, 0));
        }));
        line.addView(dateColumn, new LinearLayout.LayoutParams(0, -2, 1));
        Button toggle = button(controlsExpanded ? "收起 ▲" : "操作 ▼", false);
        toggle.setTextSize(12);
        toggle.setContentDescription(controlsExpanded ? "收起操作选项" : "展开操作选项");
        toggle.setOnClickListener(v -> {
            controlsExpanded = !controlsExpanded;
            refresh();
            mainScroll.post(() -> mainScroll.scrollTo(0, 0));
        });
        line.addView(toggle, margins(-2, dp(34), 5, 0, 0, 0));
        summary.addView(line);
        parent.addView(summary, margins(-1, -2, 0, 0, 0, 8));
    }

    private int[] counts(LocalDate date) {
        List<Entry> entries = db.forDate(date);
        int[] result = {0, 0, 0, 0};
        for (Entry e : entries) {
            if (e.kind != 0) continue;
            result[0]++;
            if (db.isDone(e.id, date.toString())) result[2]++;
        }
        for (Db.TaskOccurrence t : db.tasksForDate(date)) {
            result[1]++;
            if (t.completed) result[2]++;
            if (t.dueDate.isBefore(date) && !t.completed) result[3]++;
        }
        return result;
    }

    /** Buttons live in the collapsible panel, directly below the date card. */
    private void renderTabs(LinearLayout parent) {
        LinearLayout tools = vertical();
        tools.setPadding(dp(9), dp(9), dp(9), dp(9));
        tools.setBackground(shape(PANEL, BORDER, 13));
        LinearLayout caption = horizontal();
        TextView title = label("超市订货提醒", 17, WHITE, true);
        caption.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        Button settings = button("设置", false);
        settings.setOnClickListener(v -> openSettings());
        caption.addView(settings, margins(-2, dp(36), 5, 0, 0, 0));
        tools.addView(caption, margins(-1, -2, 0, 0, 0, 5));
        int[] c = counts(selectedDate);
        String summary = "订货 " + c[0] + " · 事务 " + c[1] + " · 已完成 " + c[2]
                + "/" + (c[0] + c[1]) + (c[3] > 0 ? " · 逾期 " + c[3] : "") + " · 09:30 提醒";
        tools.addView(label(summary, 11, c[3] > 0 ? OVERDUE : MUTED, false), margins(-1, -2, 0, 0, 0, 8));

        LinearLayout modes = horizontal();
        Button today = button("当天清单", !weekMode);
        today.setOnClickListener(v -> { weekMode = false; mainScroll.scrollTo(0, 0); refresh(); });
        modes.addView(today, new LinearLayout.LayoutParams(0, dp(39), 1));
        Button week = button("一周总览", weekMode);
        week.setOnClickListener(v -> { weekMode = true; mainScroll.scrollTo(0, 0); refresh(); });
        modes.addView(week, margins(0, dp(39), 6, 0, 0, 0));
        LinearLayout.LayoutParams second = (LinearLayout.LayoutParams) week.getLayoutParams();
        second.width = 0;
        second.weight = 1;
        week.setLayoutParams(second);
        tools.addView(modes);

        LinearLayout nav = horizontal();
        Button prev = button("‹", false);
        prev.setTextSize(20);
        prev.setOnClickListener(v -> { selectedDate = selectedDate.minusDays(weekMode ? 7 : 1); refresh(); });
        nav.addView(prev, margins(dp(41), dp(40), 0, 0, 0, 0));
        Button date = button(weekMode ? "选择周 " + selectedDate.getMonthValue() + "/" + selectedDate.getDayOfMonth()
                : "选择日期 " + selectedDate.getMonthValue() + "/" + selectedDate.getDayOfMonth(), false);
        date.setOnClickListener(v -> pickDate(selectedDate, d -> { selectedDate = d; refresh(); }));
        nav.addView(date, margins(0, dp(40), 5, 0, 5, 0));
        LinearLayout.LayoutParams dateLp = (LinearLayout.LayoutParams) date.getLayoutParams();
        dateLp.width = 0;
        dateLp.weight = 1;
        date.setLayoutParams(dateLp);
        Button next = button("›", false);
        next.setTextSize(20);
        next.setOnClickListener(v -> { selectedDate = selectedDate.plusDays(weekMode ? 7 : 1); refresh(); });
        nav.addView(next, margins(dp(41), dp(40), 0, 0, 0, 0));
        Button backToday = button("今天", false);
        backToday.setOnClickListener(v -> { selectedDate = LocalDate.now(); refresh(); });
        nav.addView(backToday, margins(-2, dp(40), 5, 0, 0, 0));
        tools.addView(nav, margins(-1, -2, 0, 7, 0, 0));

        LinearLayout actions = horizontal();
        Button order = button("＋ 添加订货", true);
        order.setOnClickListener(v -> editEntry(null, 0, selectedDate));
        actions.addView(order, new LinearLayout.LayoutParams(0, dp(40), 1));
        Button task = button("＋ 添加事务", false);
        task.setOnClickListener(v -> editEntry(null, 1, selectedDate));
        actions.addView(task, margins(0, dp(40), 6, 0, 0, 0));
        LinearLayout.LayoutParams taskLp = (LinearLayout.LayoutParams) task.getLayoutParams();
        taskLp.width = 0;
        taskLp.weight = 1;
        task.setLayoutParams(taskLp);
        tools.addView(actions, margins(-1, -2, 0, 7, 0, 0));
        Button demandLibrary = button("按需货品库（随时订货）", false);
        demandLibrary.setOnClickListener(v -> showDemandLibrary());
        tools.addView(demandLibrary, margins(-1, dp(39), 0, 7, 0, 0));

        LinearLayout extras = horizontal();
        Button density = button(compactList ? "清单：紧凑 ✓" : "清单：标准", false);
        density.setOnClickListener(v -> { compactList = !compactList; refresh(); });
        extras.addView(density, new LinearLayout.LayoutParams(0, dp(37), 1));
        Button reset = button("重置当天勾选", false);
        reset.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("重置完成记录")
                .setMessage("确定清除 " + selectedDate.format(dateFormat) + " 的所有完成勾选吗？不会删除订货或事务。")
                .setNegativeButton("取消", null)
                .setPositiveButton("重置", (d, which) -> { db.resetDay(selectedDate.toString()); refresh(); })
                .show());
        extras.addView(reset, margins(0, dp(37), 6, 0, 0, 0));
        LinearLayout.LayoutParams resetLp = (LinearLayout.LayoutParams) reset.getLayoutParams();
        resetLp.width = 0;
        resetLp.weight = 1;
        reset.setLayoutParams(resetLp);
        tools.addView(extras, margins(-1, -2, 0, 7, 0, 0));

        parent.addView(tools, margins(-1, -2, 0, 0, 0, 8));
    }

    /** Orders and business errands use separate bordered cards. */
    private void renderDay(LinearLayout parent, LocalDate date, boolean compact) {
        section(parent, date, db.forDate(date), 0, compact);
        List<Db.TaskOccurrence> tasks = db.tasksForDate(date);
        List<Db.TaskOccurrence> early = db.advanceTasksForDate(date);
        if (!tasks.isEmpty() || !early.isEmpty()) taskSection(parent, date, tasks, early);
    }

    private void renderWeek(LinearLayout parent) {
        LocalDate monday = selectedDate.minusDays(selectedDate.getDayOfWeek().getValue() - 1);
        parent.addView(label(monday.format(dateFormat) + " — " + monday.plusDays(6).format(dateFormat),
                13, MUTED, false), margins(-1, -2, 0, 0, 0, 8));
        for (int day = 0; day < 7; day++) {
            LocalDate date = monday.plusDays(day);
            LinearLayout dayBlock = vertical();
            dayBlock.setPadding(dp(9), dp(8), dp(9), dp(9));
            dayBlock.setBackground(shape(PANEL, BORDER, 12));
            LinearLayout headline = horizontal();
            TextView heading = label(WEEKDAYS[day] + "  " + date.getMonthValue() + "月" + date.getDayOfMonth() + "日",
                    16, date.equals(LocalDate.now()) ? ACCENT : WHITE, true);
            headline.addView(heading, new LinearLayout.LayoutParams(0, -2, 1));
            Button open = button("打开当天", false);
            open.setOnClickListener(v -> {
                selectedDate = date;
                weekMode = false;
                refresh();
                mainScroll.post(() -> mainScroll.scrollTo(0, 0));
            });
            headline.addView(open);
            dayBlock.addView(headline);
            String holidayNote = Holidays.notice(this, date);
            if (!holidayNote.isEmpty())
                dayBlock.addView(label(holidayNote, 11, OVERDUE, false), margins(-1, -2, 0, 0, 0, 4));
            int[] c = counts(date);
            dayBlock.addView(label("订货 " + c[0] + "  ·  事务 " + c[1] + "  ·  完成 " + c[2] + "/" +
                    (c[0] + c[1]) + (c[3] > 0 ? "  ·  逾期 " + c[3] : ""), 11, MUTED, false),
                    margins(-1, -2, 0, 3, 0, 6));
            List<Entry> orders = db.forDate(date);
            int numOrders = 0;
            for (Entry e : orders) if (e.kind == 0) numOrders++;
            if (numOrders > 0) section(dayBlock, date, orders, 0, true);
            List<Db.TaskOccurrence> tasks = db.tasksForDate(date);
            List<Db.TaskOccurrence> early = db.advanceTasksForDate(date);
            if (!tasks.isEmpty() || !early.isEmpty()) taskSection(dayBlock, date, tasks, early);
            if (numOrders == 0 && tasks.isEmpty() && early.isEmpty())
                dayBlock.addView(label("当天没有订货和事务", 12, MUTED, false));
            parent.addView(dayBlock, margins(-1, -2, 0, 0, 0, 10));
        }
    }

    private void section(LinearLayout parent, LocalDate date, List<Entry> all, int kind, boolean compact) {
        int count = 0;
        int done = 0;
        for (Entry e : all) if (e.kind == kind) {
            count++;
            if (db.isDone(e.id, date.toString())) done++;
        }
        LinearLayout head = horizontal();
        TextView title = label("订货清单", 16, WHITE, true);
        head.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        head.addView(label("已订 " + done + "/" + count, 12, MUTED, false));
        parent.addView(head, margins(-1, -2, 0, 0, 0, 5));
        LinearLayout holder = vertical();
        holder.setPadding(dp(5), dp(2), dp(5), dp(2));
        holder.setBackground(shape(PANEL, BORDER, 13));
        if (count == 0) {
            TextView empty = label("当天没有订货项目", 13, MUTED, false);
            empty.setPadding(dp(10), dp(12), dp(10), dp(12));
            holder.addView(empty);
        } else {
            for (Entry e : all) if (e.kind == kind)
                holder.addView(itemRow(e, date, compactList, false, date));
        }
        parent.addView(holder);
    }

    /** Task card exists only if the selected day has errands or overdue errands. */
    private void taskSection(LinearLayout parent, LocalDate date, List<Db.TaskOccurrence> tasks, List<Db.TaskOccurrence> early) {
        LinearLayout head = horizontal();
        TextView title = label("提醒事务", 16, WHITE, true);
        head.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        int done = 0, overdue = 0;
        for (Db.TaskOccurrence t : tasks) {
            if (t.completed) done++;
            if (t.dueDate.isBefore(date) && !t.completed) overdue++;
        }
        String progress = "完成 " + done + "/" + tasks.size() + (overdue > 0 ? "  ·  逾期 " + overdue : "");
        head.addView(label(progress, 12, overdue > 0 ? OVERDUE : MUTED, false));
        parent.addView(head, margins(-1, -2, 0, 12, 0, 5));
        LinearLayout holder = vertical();
        holder.setPadding(dp(5), dp(2), dp(5), dp(2));
        holder.setBackground(shape(PANEL, BORDER, 13));
        for (Db.TaskOccurrence t : tasks)
            holder.addView(itemRow(t.entry, date, compactList, false, t.dueDate));
        for (Db.TaskOccurrence t : early) {
            LinearLayout earlyRow = vertical();
            earlyRow.setPadding(dp(10), dp(7), dp(10), dp(7));
            earlyRow.addView(label("⏰ 提前" + t.entry.advanceDays + "天：" + t.entry.title, 13, ACCENT, true));
            earlyRow.addView(label("计划：" + t.dueDate.format(dateFormat) + " · 点击查看到期日", 11, MUTED, false));
            earlyRow.setOnClickListener(v -> {
                selectedDate = t.dueDate;
                weekMode = false;
                refresh();
                mainScroll.post(() -> mainScroll.scrollTo(0, 0));
            });
            holder.addView(earlyRow);
        }
        parent.addView(holder);
    }

    /** Two lines are preserved in compact mode: name + phone/date. */
    private View itemRow(Entry e, LocalDate visibleDate, boolean compact, boolean showDetails, LocalDate dueDate) {
        boolean done = db.isDone(e.id, dueDate.toString());
        LinearLayout row = horizontal();
        row.setMinimumHeight(dp(compact ? 51 : 62));
        row.setPadding(dp(0), dp(compact ? 2 : 5), dp(0), dp(compact ? 2 : 5));
        CheckBox check = new CheckBox(this);
        check.setButtonTintList(ColorStateList.valueOf(ACCENT));
        check.setChecked(done);
        check.setContentDescription((done ? "取消完成 " : "标记完成 ") + e.title);
        check.setOnCheckedChangeListener((v, checked) -> {
            db.setDone(e.id, dueDate.toString(), checked, visibleDate.toString());
            refresh();
        });
        row.addView(check, margins(dp(39), dp(46), 0, 0, 0, 0));
        LinearLayout information = vertical();
        TextView name = label(e.title, compact ? 14 : 16, done ? MUTED : WHITE, true);
        name.setSingleLine(!showDetails);
        if (!showDetails) name.setEllipsize(TruncateAt.END);
        if (done) name.setPaintFlags(name.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        information.addView(name);
        String subtitle;
        int subtitleColor = MUTED;
        if (e.kind == 0) {
            subtitle = e.phone.trim().isEmpty() ? "电话：待添加" : "电话：" + e.phone;
            if (e.templateId > 0) subtitle += " · 按需本次";
        } else {
            if (dueDate.isBefore(visibleDate)) {
                long days = java.time.temporal.ChronoUnit.DAYS.between(dueDate, visibleDate);
                subtitle = "逾期 " + days + " 天 · 原定 " + dueDate.getMonthValue() + "月" + dueDate.getDayOfMonth() + "日";
                subtitleColor = done ? MUTED : OVERDUE;
                if (e.repeatType == 2) subtitle += " · 每月" + e.monthDay + "日";
                else if (e.repeatType == 1) subtitle += " · 每周" + WEEKDAYS[e.weekday - 1];
            } else if (e.repeatType == 0) {
                subtitle = "计划：" + dueDate.format(dateFormat);
            } else if (e.repeatType == 2) {
                subtitle = "每月" + e.monthDay + "日循环";
                if (e.monthDay > visibleDate.lengthOfMonth()) subtitle += " · 本月末执行";
            } else {
                subtitle = "每周" + WEEKDAYS[e.weekday - 1] + "循环";
            }
        }
        if (e.kind == 1 && e.advanceDays > 0) subtitle += " · 提前" + e.advanceDays + "天+当天";
        if (e.reminderMinute >= 0) subtitle += "  ·  ⏰" + minuteLabel(e.reminderMinute);
        TextView details = label(subtitle, compact ? 11 : 12, subtitleColor, false);
        details.setSingleLine(true);
        details.setEllipsize(TruncateAt.END);
        information.addView(details, margins(-1, -2, 0, 1, 0, 0));
        if ((!compact || showDetails) && !e.note.trim().isEmpty()) {
            TextView noteText = label(e.note, 11, MUTED, false);
            information.addView(noteText, margins(-1, -2, 0, 2, 0, 0));
        }
        information.setOnClickListener(v -> editEntry(e, e.kind, visibleDate));
        row.addView(information, new LinearLayout.LayoutParams(0, -2, 1));
        if (!e.phone.trim().isEmpty()) {
            Button wa = button("WA", true);
            wa.setTextSize(11);
            wa.setPadding(dp(5), dp(3), dp(5), dp(3));
            wa.setContentDescription("在 WhatsApp Business 打开 " + e.title + " 的对话");
            wa.setOnClickListener(v -> openWhatsApp(e.phone));
            row.addView(wa, margins(-2, dp(34), 3, 0, 3, 0));
        }
        Button edit = button("编辑", false);
        edit.setTextSize(11);
        edit.setPadding(dp(6), dp(3), dp(6), dp(3));
        edit.setContentDescription("编辑 " + e.title);
        edit.setOnClickListener(v -> editEntry(e, e.kind, visibleDate));
        row.addView(edit, margins(-2, dp(34), 1, 0, 1, 0));
        return row;
    }

    private void openWhatsApp(String phone) {
        String digits = phone.replaceAll("[^0-9]", "");
        // Remove a typed international 00 prefix; WhatsApp wants country-code digits only.
        if (digits.startsWith("00")) digits = digits.substring(2);
        if (digits.isEmpty()) { toast("请先编辑并填写 WhatsApp 国际区号和手机号码"); return; }
        // Always use WhatsApp Business, never accidentally switch to personal WhatsApp.
        String businessPackage = "com.whatsapp.w4b";
        Intent deepLink = new Intent(Intent.ACTION_VIEW,
                Uri.parse("whatsapp://send?phone=" + digits));
        deepLink.setPackage(businessPackage);
        try { startActivity(deepLink); return; }
        catch (Exception ignored) { }
        Intent webLink = new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + digits));
        webLink.setPackage(businessPackage);
        try { startActivity(webLink); return; }
        catch (Exception ignored) { }
        new AlertDialog.Builder(this)
                .setTitle("需要 WhatsApp Business")
                .setMessage("未能打开 WhatsApp Business。请确认已安装商家版，且号码包含国际区号。不会自动改用个人 WhatsApp。")
                .setNegativeButton("取消", null)
                .setPositiveButton("打开安装页面", (dialog, which) -> {
                    try { startActivity(new Intent(Intent.ACTION_VIEW,
                            Uri.parse("market://details?id=com.whatsapp.w4b"))); }
                    catch (Exception ex) { toast("请在应用商店搜索 WhatsApp Business"); }
                }).show();
    }

    private interface DateChoice { void chosen(LocalDate d); }
    private void pickDate(LocalDate initial, DateChoice handler) {
        new DatePickerDialog(this, (view, y, m, d) -> handler.chosen(LocalDate.of(y, m + 1, d)),
                initial.getYear(), initial.getMonthValue() - 1, initial.getDayOfMonth()).show();
    }

    private EditText field(String hint, String value, int inputType) {
        EditText edit = new EditText(this);
        edit.setText(value == null ? "" : value);
        edit.setTextSize(15);
        edit.setTextColor(WHITE);
        edit.setHintTextColor(MUTED);
        edit.setHint(hint);
        edit.setSingleLine(true);
        edit.setInputType(inputType);
        edit.setPadding(dp(9), dp(12), dp(9), dp(12));
        edit.setBackground(shape(PANEL_2, BORDER, 9));
        return edit;
    }

    private void formLabel(LinearLayout parent, String value) {
        parent.addView(label(value, 13, MUTED, true), margins(-1, -2, 0, 14, 0, 5));
    }

    /** A hidden catalog of occasional suppliers; never pollutes the daily checklist. */
    private void showDemandLibrary() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout list = vertical();
        list.setPadding(dp(14), dp(8), dp(14), dp(12));
        scroll.addView(list);
        TextView intro = label("按需货品没有星期限制。需要补货时点「加入今天」，或选择其他日期；未安排时不会进入每日清单，也不会提醒。", 12, MUTED, false);
        list.addView(intro, margins(-1, -2, 0, 4, 0, 8));

        Button add = button("＋ 新增按需货品", true);
        list.addView(add, margins(-1, dp(42), 0, 0, 0, 10));
        List<Entry> catalog = db.demandTemplates();
        if (catalog.isEmpty()) {
            list.addView(label("还没有按需货品。可先添加供应商，之后任何一天都能下单。", 13, MUTED, false));
        }
        for (Entry template : catalog) {
            LinearLayout card = vertical();
            card.setPadding(dp(10), dp(9), dp(10), dp(9));
            card.setBackground(shape(PANEL, BORDER, 11));
            card.addView(label(template.title, 15, WHITE, true));
            String tel = template.phone.trim().isEmpty() ? "电话：待添加" : "电话：" + template.phone;
            card.addView(label(tel + " · 随时可订", 11, MUTED, false),
                    margins(-1, -2, 0, 3, 0, 6));
            LinearLayout buttons = horizontal();
            Button todayOrder = button("加入今天", true);
            todayOrder.setOnClickListener(v -> addDemandOn(template, LocalDate.now()));
            buttons.addView(todayOrder, new LinearLayout.LayoutParams(0, dp(37), 1));
            Button schedule = button("选择日期", false);
            schedule.setOnClickListener(v -> chooseDemandDate(template));
            buttons.addView(schedule, margins(0, dp(37), 6, 0, 0, 0));
            LinearLayout.LayoutParams scheduleLp = (LinearLayout.LayoutParams) schedule.getLayoutParams();
            scheduleLp.width = 0;
            scheduleLp.weight = 1;
            schedule.setLayoutParams(scheduleLp);
            card.addView(buttons);
            LinearLayout otherButtons = horizontal();
            if (!template.phone.trim().isEmpty()) {
                Button wa = button("WA", false);
                wa.setOnClickListener(v -> openWhatsApp(template.phone));
                otherButtons.addView(wa, margins(-2, dp(33), 5, 4, 0, 0));
            }
            Button edit = button("编辑", false);
            edit.setOnClickListener(v -> {
                if (activeDemandDialog != null) activeDemandDialog.dismiss();
                editEntry(template, 0, selectedDate);
            });
            otherButtons.addView(edit, margins(-2, dp(33), 5, 4, 0, 0));
            card.addView(otherButtons);
            list.addView(card, margins(-1, -2, 0, 0, 0, 8));
        }
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("按需货品库 · " + catalog.size() + " 项")
                .setView(scroll)
                .setPositiveButton("关闭", null)
                .create();
        add.setOnClickListener(v -> { dialog.dismiss(); createDemandTemplate(); });
        // Catalog remains visible while choosing a date, and closes automatically
        // after a successful add. Editing closes it to avoid stale rows.
        activeDemandDialog = dialog;
        dialog.setOnDismissListener(which -> {
            if (activeDemandDialog == dialog) activeDemandDialog = null;
        });
        dialog.show();
    }

    private void createDemandTemplate() {
        Entry item = new Entry();
        item.repeatType = 3;
        item.kind = 0;
        item.allowedWeekdays = 63;
        editEntry(item, 0, selectedDate);
    }

    private void chooseDemandDate(Entry template) {
        LocalDate start = selectedDate.isBefore(LocalDate.now()) ? LocalDate.now() : selectedDate;
        java.util.ArrayList<LocalDate> options = new java.util.ArrayList<>();
        for (LocalDate d = start; options.size() < 6; d = d.plusDays(1)) {
            options.add(d);
        }
        String[] labels = new String[options.size() + 1];
        for (int i = 0; i < options.size(); i++) {
            LocalDate d = options.get(i);
            labels[i] = d.format(dateFormat) + " " + WEEKDAYS[d.getDayOfWeek().getValue() - 1];
        }
        labels[options.size()] = "选择更远日期…";
        new AlertDialog.Builder(this)
                .setTitle(template.title + " · 选择本次订货日期")
                .setItems(labels, (dialog, which) -> {
                    if (which < options.size()) addDemandOn(template, options.get(which));
                    else pickDate(options.get(options.size()-1), chosen -> {
                        if (chosen.isBefore(LocalDate.now())) { toast("不能安排到过去的日期"); return; }
                        addDemandOn(template, chosen);
                    });
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void addDemandOn(Entry template, LocalDate day) {
        try {
            Db.DemandAddResult result = db.addDemandOrder(template, day);
            if (result.created) AlarmScheduler.scheduleEntry(this, result.order);
            if (activeDemandDialog != null) activeDemandDialog.dismiss();
            selectedDate = day;
            weekMode = false;
            controlsExpanded = false;
            refresh();
            mainScroll.post(() -> mainScroll.scrollTo(0, 0));
            toast(result.created ? "已加入 " + day.format(dateFormat) + " 订货清单" : "这件货在该日期已经安排过，不重复添加");
        } catch (Exception ex) {
            toast("未能安排订货：" + ex.getMessage());
        }
    }

    private void editEntry(Entry existing, int initialKind, LocalDate date) {
        Entry e = existing == null ? new Entry() : existing;
        boolean isNew = existing == null || existing.id == 0;
        final LocalDate[] dueDate = {isNew ? date : (e.repeatType == 0 ? LocalDate.parse(e.date) : date)};
        final int[] separateMinute = {isNew ? -1 : e.reminderMinute};
        final int[] advanceDays = {isNew ? 0 : e.advanceDays};

        ScrollView dialogScroll = new ScrollView(this);
        LinearLayout form = vertical();
        form.setPadding(dp(20), dp(8), dp(20), dp(10));
        dialogScroll.addView(form);
        formLabel(form, "内容名称 *");
        EditText title = field("例如：Nestlé / 去市政府 / 交税", isNew ? "" : e.title, InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        form.addView(title);
        formLabel(form, "类别");
        Spinner kindSpinner = new Spinner(this);
        ArrayAdapter<String> kindAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, KINDS);
        kindSpinner.setAdapter(kindAdapter);
        kindSpinner.setSelection(isNew ? initialKind : e.kind);
        form.addView(kindSpinner);
        formLabel(form, "重复方式");
        RadioGroup freq = new RadioGroup(this);
        freq.setOrientation(LinearLayout.VERTICAL);
        RadioButton weekly = new RadioButton(this);
        weekly.setId(View.generateViewId());
        weekly.setText("② 每周固定星期循环 · 指定一天自动出现");
        weekly.setTextColor(WHITE);
        weekly.setButtonTintList(ColorStateList.valueOf(ACCENT));
        RadioButton dailyOrder = new RadioButton(this);
        dailyOrder.setId(View.generateViewId());
        dailyOrder.setText("① 固定多日订货 · 自选周一至周日（可多选）");
        dailyOrder.setTextColor(WHITE);
        dailyOrder.setButtonTintList(ColorStateList.valueOf(ACCENT));
        RadioButton once = new RadioButton(this);
        once.setId(View.generateViewId());
        once.setText("仅指定日期（适合几天后的事情）");
        once.setTextColor(WHITE);
        once.setButtonTintList(ColorStateList.valueOf(ACCENT));
        RadioButton demand = new RadioButton(this);
        demand.setId(View.generateViewId());
        demand.setText("③ 随时按需订货 · 不限星期、不自动出现");
        demand.setTextColor(WHITE);
        demand.setButtonTintList(ColorStateList.valueOf(ACCENT));
        RadioButton monthly = new RadioButton(this);
        monthly.setId(View.generateViewId());
        monthly.setText("每月固定日期循环（适合水电费、税费）");
        monthly.setTextColor(WHITE);
        monthly.setButtonTintList(ColorStateList.valueOf(ACCENT));
        freq.addView(weekly);
        freq.addView(dailyOrder);
        freq.addView(demand);
        freq.addView(monthly);
        freq.addView(once);
        int chosenRepeat = existing != null ? e.repeatType : (initialKind == 0 ? 1 : 0);
        if (chosenRepeat == 1) weekly.setChecked(true);
        else if (chosenRepeat == 4) dailyOrder.setChecked(true);
        else if (chosenRepeat == 2) monthly.setChecked(true);
        else if (chosenRepeat == 3) demand.setChecked(true);
        else once.setChecked(true);
        form.addView(freq);

        LinearLayout weeklyFields = vertical();
        formLabel(weeklyFields, "每周哪一天");
        Spinner weekPicker = new Spinner(this);
        ArrayAdapter<String> dayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, WEEKDAYS);
        weekPicker.setAdapter(dayAdapter);
        weekPicker.setSelection((isNew ? date.getDayOfWeek().getValue() : e.weekday) - 1);
        weeklyFields.addView(weekPicker);
        form.addView(weeklyFields);

        // Keep the original three ordering types. Repeat type 4 now has its own
        // seven checkboxes instead of assuming Monday through Saturday.
        LinearLayout dailyFields = vertical();
        formLabel(dailyFields, "选择每周自动出现的日子（可多选）");
        dailyFields.addView(label("例如：面包周一至周日；另一种货只选周一、周三、周五。默认周一至周六。", 12, MUTED, false),
                margins(-1, -2, 0, 0, 0, 4));
        final CheckBox[] dailyDayChecks = new CheckBox[7];
        final int initialDailyMask = (!isNew && e.repeatType == 4) ? e.allowedWeekdays : 63;
        String[] shortDayNames = {"周一", "周二", "周三", "周四", "周五", "周六", "周日"};
        for (int first = 0; first < 7; first += 4) {
            LinearLayout checkRow = new LinearLayout(this);
            checkRow.setOrientation(LinearLayout.HORIZONTAL);
            for (int i = first; i < Math.min(first + 4, 7); i++) {
                CheckBox cb = new CheckBox(this);
                cb.setText(shortDayNames[i]);
                cb.setTextColor(WHITE);
                cb.setTextSize(13);
                cb.setButtonTintList(ColorStateList.valueOf(ACCENT));
                cb.setChecked((initialDailyMask & (1 << i)) != 0);
                cb.setMinHeight(dp(42));
                checkRow.addView(cb, new LinearLayout.LayoutParams(0,
                        ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                dailyDayChecks[i] = cb;
            }
            dailyFields.addView(checkRow);
        }
        form.addView(dailyFields);

        LinearLayout demandFields = vertical();
        demandFields.addView(label("保存到按需货品库后，任何星期均可直接「加入今天」，也可以安排将来的日期。未安排就不会出现在每日清单。", 12, MUTED, false),
                margins(-1, -2, 0, 9, 0, 0));
        form.addView(demandFields);

        LinearLayout monthlyFields = vertical();
        formLabel(monthlyFields, "每月固定几号");
        Spinner monthPicker = new Spinner(this);
        String[] monthDays = new String[31];
        for (int d = 1; d <= 31; d++) monthDays[d - 1] = "每月 " + d + " 日";
        ArrayAdapter<String> monthAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, monthDays);
        monthPicker.setAdapter(monthAdapter);
        monthPicker.setSelection((isNew ? date.getDayOfMonth() : Math.max(1, Math.min(31, e.monthDay))) - 1);
        monthlyFields.addView(monthPicker);
        monthlyFields.addView(label("如选择 29、30 或 31 日，遇到短月份自动安排在当月最后一天。", 11, MUTED, false),
                margins(-1, -2, 0, 4, 0, 0));
        form.addView(monthlyFields);

        LinearLayout dateFields = vertical();
        formLabel(dateFields, "计划日期");
        Button dateButton = button(dueDate[0].format(dateFormat) + " · 点击修改日期", false);
        dateButton.setOnClickListener(v -> pickDate(dueDate[0], d -> {
            dueDate[0] = d;
            dateButton.setText(d.format(dateFormat) + " · 点击修改日期");
        }));
        dateFields.addView(dateButton);
        form.addView(dateFields);
        weeklyFields.setVisibility(chosenRepeat == 1 ? View.VISIBLE : View.GONE);
        dailyFields.setVisibility(chosenRepeat == 4 ? View.VISIBLE : View.GONE);
        demandFields.setVisibility(chosenRepeat == 3 ? View.VISIBLE : View.GONE);
        monthlyFields.setVisibility(chosenRepeat == 2 ? View.VISIBLE : View.GONE);
        dateFields.setVisibility(chosenRepeat == 0 ? View.VISIBLE : View.GONE);
        freq.setOnCheckedChangeListener((group, checkedId) -> {
            weeklyFields.setVisibility(checkedId == weekly.getId() ? View.VISIBLE : View.GONE);
            dailyFields.setVisibility(checkedId == dailyOrder.getId() ? View.VISIBLE : View.GONE);
            demandFields.setVisibility(checkedId == demand.getId() ? View.VISIBLE : View.GONE);
            monthlyFields.setVisibility(checkedId == monthly.getId() ? View.VISIBLE : View.GONE);
            dateFields.setVisibility(checkedId == once.getId() ? View.VISIBLE : View.GONE);
        });

        // In the ordering editor only three primary ordering types are shown.
        // Errands have their own scheduling choices: once / weekly / monthly.
        // Already-scheduled single orders remain editable without exposing a
        // fourth primary ordering mode when adding a NEW supplier.
        Runnable updateCategoryOptions = () -> {
            boolean isOrder = kindSpinner.getSelectedItemPosition() == 0;
            boolean editingSingleOrder = !isNew && existing != null
                    && existing.kind == 0 && existing.repeatType == 0;
            dailyOrder.setVisibility(isOrder ? View.VISIBLE : View.GONE);
            demand.setVisibility(isOrder ? View.VISIBLE : View.GONE);
            monthly.setVisibility(isOrder ? View.GONE : View.VISIBLE);
            once.setVisibility(!isOrder || editingSingleOrder ? View.VISIBLE : View.GONE);
            if (isOrder) {
                if (monthly.isChecked() || (once.isChecked() && !editingSingleOrder))
                    weekly.setChecked(true);
            } else if (dailyOrder.isChecked() || demand.isChecked()) {
                once.setChecked(true);
            }
        };
        kindSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                updateCategoryOptions.run();
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });
        updateCategoryOptions.run();

        formLabel(form, "WhatsApp Business 号码（可空，带国际区号）");
        EditText phone = field("例如：+54 9 11 1234 5678", isNew ? "" : e.phone, InputType.TYPE_CLASS_PHONE);
        form.addView(phone);
        form.addView(label("点击 WA 会在 WhatsApp Business 中进入该号码的对话。历史图片和 PDF 以该 Business 账号已有聊天记录为准。", 11, MUTED, false),
                margins(-1, -2, 0, 5, 0, 0));
        formLabel(form, "备注（可空）");
        EditText note = field("订货数量、送货时间或办事说明", isNew ? "" : e.note, InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        note.setSingleLine(false);
        note.setMinLines(2);
        form.addView(note);

        formLabel(form, "该项目单独提醒（可选；每天 09:30 总提醒始终开启）");
        Button reminder = button(separateMinute[0] < 0 ? "不设置单独提醒" : "单独提醒：" + minuteLabel(separateMinute[0]), false);
        reminder.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setItems(new String[]{"设定单独提醒时间", "取消单独提醒"}, (dialog, which) -> {
                    if (which == 1) {
                        separateMinute[0] = -1;
                        reminder.setText("不设置单独提醒");
                    } else {
                        int current = separateMinute[0] < 0 ? 600 : separateMinute[0];
                        new TimePickerDialog(this, (time, hour, minute) -> {
                            separateMinute[0] = hour * 60 + minute;
                            reminder.setText("单独提醒：" + minuteLabel(separateMinute[0]));
                        }, current / 60, current % 60, true).show();
                    }
                }).show());
        form.addView(reminder);
        formLabel(form, "事务提前提醒（事务当天 09:30 始终提醒）");
        Button advancePicker = button(advanceDays[0] == 0
                ? "仅当天提醒 · 不提前"
                : "提前 " + advanceDays[0] + " 天＋当天提醒", false);
        final int[] choices = {0, 1, 2, 3, 5, 7, 10, 15, 30};
        final String[] choiceLabels = {"仅当天提醒", "提前 1 天", "提前 2 天", "提前 3 天",
                "提前 5 天", "提前 7 天", "提前 10 天", "提前 15 天", "提前 30 天", "自定义天数…"};
        advancePicker.setOnClickListener(v -> {
            int selected = -1;
            for (int i = 0; i < choices.length; i++)
                if (advanceDays[0] == choices[i]) selected = i;
            new AlertDialog.Builder(this)
                    .setTitle("提前几天提醒？（当天仍会提醒）")
                    .setSingleChoiceItems(choiceLabels, selected, (pickDialog, index) -> {
                        pickDialog.dismiss();
                        if (index < choices.length) {
                            advanceDays[0] = choices[index];
                            advancePicker.setText(advanceDays[0] == 0 ? "仅当天提醒 · 不提前"
                                    : "提前 " + advanceDays[0] + " 天＋当天提醒");
                            return;
                        }
                        EditText inputDays = field("输入 1 至 365 天", advanceDays[0] > 0
                                ? Integer.toString(advanceDays[0]) : "", InputType.TYPE_CLASS_NUMBER);
                        inputDays.setSingleLine(true);
                        LinearLayout customBox = vertical();
                        customBox.setPadding(dp(22), dp(14), dp(22), dp(6));
                        customBox.addView(label("输入提前天数（自然日）", 13, WHITE, false));
                        customBox.addView(inputDays);
                        AlertDialog custom = new AlertDialog.Builder(this)
                                .setTitle("自定义提醒天数")
                                .setView(customBox)
                                .setNegativeButton("取消", null)
                                .setPositiveButton("确定", null)
                                .create();
                        custom.setOnShowListener(ignored -> custom.getButton(AlertDialog.BUTTON_POSITIVE)
                                .setOnClickListener(tap -> {
                                    int days;
                                    try { days = Integer.parseInt(inputDays.getText().toString().trim()); }
                                    catch (Exception error) { inputDays.setError("请输入数字"); return; }
                                    if (days < 1 || days > 365) {
                                        inputDays.setError("请选择 1 至 365 天"); return;
                                    }
                                    advanceDays[0] = days;
                                    advancePicker.setText("提前 " + days + " 天＋当天提醒");
                                    custom.dismiss();
                                }));
                        custom.show();
                    })
                    .setNegativeButton("取消", null)
                    .show();
        });
        form.addView(advancePicker, margins(-1, dp(44), 0, 7, 0, 0));
        advancePicker.setVisibility(kindSpinner.getSelectedItemPosition() == 1 ? View.VISIBLE : View.GONE);
        // Updating selection can occur after user changes order/task category.
        kindSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                updateCategoryOptions.run();
                advancePicker.setVisibility(position == 1 ? View.VISIBLE : View.GONE);
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });
        form.addView(label("事务总会在到期当天 09:30 提醒；可额外选择提前 1–365 个自然日于 09:30 提醒。提前通知不算逾期，完成本次事务后不会重复提醒。", 11, MUTED, false));

        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setTitle(isNew ? "添加订货 / 事务" : "编辑项目")
                .setView(dialogScroll)
                .setNegativeButton("取消", null)
                .setPositiveButton("保存", null);
        if (!isNew) builder.setNeutralButton("删除", (d, w) -> new AlertDialog.Builder(this)
                .setTitle("删除项目？")
                .setMessage("“" + e.title + "”将被永久删除。若它是循环项目，以后的所有对应日期也会一起删除。")
                .setNegativeButton("取消", null)
                .setPositiveButton("确定删除", (d2, w2) -> {
                    AlarmScheduler.cancel(this, e.id);
                    db.delete(e.id);
                    refresh();
                }).show());
        AlertDialog dialog = builder.create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String name = title.getText().toString().trim();
            if (name.isEmpty()) { title.setError("请输入内容名称"); return; }
            if (name.length() > 200) { title.setError("最多 200 字"); return; }
            int previousRepeat = e.repeatType;
            e.title = name;
            e.kind = kindSpinner.getSelectedItemPosition();
            e.repeatType = weekly.isChecked() ? 1 : (dailyOrder.isChecked() ? 4 :
                    (monthly.isChecked() ? 2 : (demand.isChecked() ? 3 : 0)));
            if ((e.repeatType == 3 || e.repeatType == 4) && e.kind != 0) {
                toast("每天固定和随时按需仅适用于订货；事务请选择单次、每周或每月"); return;
            }
            int selectedWeekdayMask = 0;
            for (int i = 0; i < dailyDayChecks.length; i++) {
                if (dailyDayChecks[i].isChecked()) selectedWeekdayMask |= (1 << i);
            }
            if (e.repeatType == 4 && selectedWeekdayMask == 0) {
                toast("请至少选择一个订货星期"); return;
            }
            // Only the fixed multi-day type uses this mask; demand remains unrestricted.
            e.allowedWeekdays = e.repeatType == 4 ? selectedWeekdayMask : 63;
            if (e.repeatType == 4 && previousRepeat != 4) {
                e.startDate = LocalDate.now().toString(); // Do not add daily orders to old calendar days.
            }
            e.weekday = weekPicker.getSelectedItemPosition() + 1;
            e.monthDay = monthPicker.getSelectedItemPosition() + 1;
            e.date = dueDate[0].toString();
            e.phone = phone.getText().toString().trim();
            e.note = note.getText().toString().trim();
            e.reminderMinute = separateMinute[0];
            e.advanceDays = e.kind == 1 ? advanceDays[0] : 0;
            if (e.phone.length() > 80 || e.note.length() > 500) {
                toast("号码限 80 字符；备注限 500 字符"); return;
            }
            db.save(e);
            AlarmScheduler.scheduleEntry(this, e);
            dialog.dismiss();
            refresh();
            toast("已保存");
        }));
        dialog.show();
    }

    private String minuteLabel(int minute) { return String.format(Locale.ROOT, "%02d:%02d", minute / 60, minute % 60); }

    private boolean exactAllowed() {
        AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
        return Build.VERSION.SDK_INT < 31 || (am != null && am.canScheduleExactAlarms());
    }

    private boolean notificationAllowed() {
        return Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    }

    private void askNotificationPermission() {
        if (!notificationAllowed() && Build.VERSION.SDK_INT >= 33)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 301);
    }

    private void openSettings() {
        ScrollView sc = new ScrollView(this);
        LinearLayout body = vertical();
        body.setPadding(dp(20), dp(14), dp(20), dp(20));
        sc.addView(body);
        body.addView(label("每天上午 09:30 自动提醒（包括周日）。固定订货按选择的星期出现，按需货品可随时安排。事务可自选提前1–365天和当天双提醒；日期栏展示阿根廷节日及7天前预告（自动同步节日 API，断网读取缓存）。", 15, WHITE, false));
        body.addView(label("通知权限：" + (notificationAllowed() ? "已允许 ✓" : "未允许，需要开启"), 14,
                notificationAllowed() ? ACCENT : WHITE, true), margins(-1, -2, 0, 15, 0, 3));
        body.addView(label("准点闹钟权限：" + (exactAllowed() ? "已允许 ✓" : "未允许，仅能尽力提醒，可能延迟"), 14,
                exactAllowed() ? ACCENT : WHITE, true), margins(-1, -2, 0, 7, 0, 5));
        Button notification = button("开启通知权限", false);
        notification.setOnClickListener(v -> { askNotificationPermission(); if (notificationAllowed()) toast("通知已允许"); });
        body.addView(notification, margins(-1, dp(43), 0, 9, 0, 0));
        Button precise = button("开启准点闹钟权限（重要）", true);
        precise.setOnClickListener(v -> requestExactAlarm());
        body.addView(precise, margins(-1, dp(45), 0, 9, 0, 0));
        Button test = button("发送一条测试通知", false);
        test.setOnClickListener(v -> {
            if (!notificationAllowed()) { askNotificationPermission(); toast("请先允许通知，再测试"); return; }
            ReminderReceiver.show(this, "超市订货提醒测试", "通知正常。每天 09:30 将发送今日清单提醒。", 900200, LocalDate.now());
            toast("已发送测试通知");
        });
        body.addView(test, margins(-1, dp(43), 0, 9, 0, 0));
        Button power = button("打开系统 App 设置（检查电池限制）", false);
        power.setOnClickListener(v -> {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        });
        body.addView(power, margins(-1, dp(43), 0, 9, 0, 0));
        body.addView(label("注意：Android 的省电策略、关机和系统权限可能影响准点通知。启用上面两项权限并允许本应用后台运行。", 12, MUTED, false),
                margins(-1, -2, 0, 10, 0, 5));
        Button export = button("导出全部清单 / 联系人 / 完成记录（JSON）", false);
        export.setOnClickListener(v -> exportBackup());
        body.addView(export, margins(-1, dp(48), 0, 15, 0, 0));
        Button restore = button("导入 JSON 备份（覆盖现有清单）", false);
        restore.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("恢复备份")
                .setMessage("导入将覆盖目前所有订货、号码、事务和完成记录。建议先导出当前清单。")
                .setNegativeButton("取消", null)
                .setPositiveButton("选择备份文件", (d, w) -> importBackup()).show());
        body.addView(restore, margins(-1, dp(45), 0, 9, 0, 0));
        body.addView(label("资料仅储存于此手机。卸载应用可能清除数据，请定期导出备份。", 12, MUTED, false),
                margins(-1, -2, 0, 12, 0, 0));
        new AlertDialog.Builder(this).setTitle("提醒设置与数据备份")
                .setView(sc).setPositiveButton("完成", (d, w) -> {
                    AlarmScheduler.scheduleAll(this);
                    refresh();
                }).show();
    }

    private void requestExactAlarm() {
        if (exactAllowed()) { toast("准点闹钟权限已允许"); return; }
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                        Uri.parse("package:" + getPackageName())));
            } catch (Exception exception) {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:" + getPackageName())));
            }
        }
    }

    private void exportBackup() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        intent.putExtra(Intent.EXTRA_TITLE, "超市订货备份_" + LocalDate.now() + ".json");
        startActivityForResult(intent, CREATE_BACKUP);
    }

    private void importBackup() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(intent, OPEN_BACKUP);
    }

    @Override @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri file = data.getData();
        try {
            if (requestCode == CREATE_BACKUP) {
                JSONObject root = db.backup(getSharedPreferences(AlarmScheduler.PREFS, MODE_PRIVATE));
                try (OutputStream os = getContentResolver().openOutputStream(file)) {
                    if (os == null) throw new Exception("无法写入文件");
                    os.write(root.toString(2).getBytes(StandardCharsets.UTF_8));
                }
                toast("备份已保存");
            } else if (requestCode == OPEN_BACKUP) {
                ByteArrayOutputStream buf = new ByteArrayOutputStream();
                try (InputStream in = getContentResolver().openInputStream(file)) {
                    if (in == null) throw new Exception("无法读取文件");
                    byte[] bytes = new byte[8192];
                    int n;
                    while ((n = in.read(bytes)) >= 0) {
                        if (buf.size() + n > 10 * 1024 * 1024) throw new Exception("备份文件不能超过 10 MB");
                        buf.write(bytes, 0, n);
                    }
                }
                JSONObject root = new JSONObject(new String(buf.toByteArray(), StandardCharsets.UTF_8));
                // Cancel old individual alarms before replacing database entries.
                for (Entry e : db.allEntries()) AlarmScheduler.cancel(this, e.id);
                db.restore(root, getSharedPreferences(AlarmScheduler.PREFS, MODE_PRIVATE));
                AlarmScheduler.scheduleAll(this);
                selectedDate = LocalDate.now();
                refresh();
                toast("备份恢复成功");
            }
        } catch (Exception ex) {
            new AlertDialog.Builder(this).setTitle("操作失败")
                    .setMessage(ex.getMessage() == null ? "无法处理此备份文件" : ex.getMessage())
                    .setPositiveButton("确定", null).show();
        }
    }

    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_LONG).show(); }
}
