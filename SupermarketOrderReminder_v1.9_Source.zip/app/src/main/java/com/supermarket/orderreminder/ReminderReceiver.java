package com.supermarket.orderreminder;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ReminderReceiver extends BroadcastReceiver {
    public static final String CHANNEL_ID = "supermarket_daily_v1";

    public static void createChannel(Context c) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "订货和事务提醒", NotificationManager.IMPORTANCE_DEFAULT);
        channel.setDescription("每天待办与单项指定时间提醒");
        nm.createNotificationChannel(channel);
    }

    private static boolean canNotify(Context c) {
        return Build.VERSION.SDK_INT < 33 || c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    }

    public static void show(Context c, String title, String message, int notificationId, LocalDate date) {
        createChannel(c);
        if (!canNotify(c)) return;
        Intent open = new Intent(c, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        open.putExtra("open_date", date.toString());
        PendingIntent tap = PendingIntent.getActivity(c, notificationId, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification notification = new Notification.Builder(c, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle(title)
                .setContentText(message)
                .setStyle(new Notification.BigTextStyle().bigText(message))
                .setContentIntent(tap)
                .setAutoCancel(true)
                .setCategory(Notification.CATEGORY_REMINDER)
                .build();
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(notificationId, notification);
    }

    @Override public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        long id = intent.getLongExtra(AlarmScheduler.EXTRA_ID, AlarmScheduler.DAILY);
        Db db = new Db(context);
        try {
            LocalDate today = LocalDate.now();
            if (id == AlarmScheduler.DAILY) {
                AlarmScheduler.scheduleDaily(context);
                // Fixed orders repeat on chosen weekdays; neither carries over. Only unfinished
                // errands carry overdue state into the next morning's notice.
                List<String> pending = new ArrayList<>();
                int overdue = 0;
                List<String> dueTaskNames = new ArrayList<>();
                int orders = 0;
                int errands = 0;
                for (Entry e : db.forDate(today)) {
                    if (e.kind == 0 && !db.isDone(e.id, today.toString())) {
                        orders++;
                        pending.add(e.title);
                    }
                }
                for (Db.TaskOccurrence t : db.tasksForDate(today)) {
                    if (t.completed) continue;
                    errands++;
                    dueTaskNames.add((t.dueDate.isBefore(today) ? "逾期：" : "今日：") + t.entry.title);
                    if (t.dueDate.isBefore(today)) {
                        overdue++;
                        pending.add("逾期：" + t.entry.title);
                    } else {
                        pending.add(t.entry.title);
                    }
                }
                StringBuilder text = new StringBuilder();
                if (pending.isEmpty()) {
                    text.append("今天没有待处理事项，可以查看未来的订货和事务。");
                } else {
                    text.append("待订货 ").append(orders).append(" 项 · 待办事务 ").append(errands).append(" 项");
                    if (overdue > 0) text.append("（逾期 ").append(overdue).append(" 项）");
                    text.append("：");
                    for (int i = 0; i < Math.min(pending.size(), 3); i++) {
                        if (i > 0) text.append("、");
                        text.append(pending.get(i));
                    }
                    if (pending.size() > 3) text.append("等");
                }
                // Refresh in the background, retaining cache for the next notice, including cross-year.
                Holidays.ensureLoaded(context, today, null);
                Holidays.ensureLoaded(context, LocalDate.of(today.getYear() + 1, 1, 1), null);
                // Cached holiday notes work offline. Both today and exactly 7 days before are shown.
                String holidays = Holidays.notice(context, today);
                if (!holidays.isEmpty()) text.append("  ·  ").append(holidays);
                show(context, "09:30 · 今日订货 / 事务", text.toString(), 100001, today);
                if (!dueTaskNames.isEmpty()) {
                    show(context, "09:30 · 今日待办事务 " + dueTaskNames.size() + "项",
                            String.join("、", dueTaskNames), 100006, today);
                }
            } else {
                Entry e = db.getEntry(id);
                if (e == null) return;
                if (AlarmScheduler.ACTION_ADVANCE.equals(intent.getAction())) {
                    // Re-arm for the next weekly/monthly occurrence before checking completion.
                    AlarmScheduler.scheduleAdvance(context, e);
                    LocalDate dueDate = ReminderRules.advanceDueOn(e, today);
                    if (dueDate != null && !db.isDone(id, dueDate.toString())) {
                        String detail = "计划日期 " + dueDate + " · 还有" + e.advanceDays + "天";
                        if (!e.note.isEmpty()) detail += " · " + e.note;
                        show(context, "提前" + e.advanceDays + "天 · " + e.title, detail,
                                (int) (id % 700000000L) + 200000001, dueDate);
                    }
                } else {
                    boolean due = Db.occursOn(e, today);
                    if (e.repeatType == 1 || e.repeatType == 2 || e.repeatType == 4)
                        AlarmScheduler.scheduleEntry(context, e);
                    if (due && !db.isDone(id, today.toString())) {
                        show(context, e.kind == 0 ? "订货提醒：" + e.title : "事务提醒：" + e.title,
                                e.note.isEmpty() ? "点击查看并标记完成" : e.note,
                                (int) (id % 700000000L) + 100002, today);
                    }
                }
            }
        } finally { db.close(); }
    }
}
