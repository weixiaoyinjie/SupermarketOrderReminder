package com.supermarket.orderreminder;

import java.time.LocalDate;

/** Pure recurrence/date calculation for task reminders with configurable lead days. */
public final class ReminderRules {
    private ReminderRules() {}

    /** Returns the corresponding due date only when a reminder should trigger on day. */
    public static LocalDate advanceDueOn(Entry e, LocalDate reminderDay) {
        if (e == null || e.kind != 1 || e.advanceDays < 1 || e.advanceDays > 365) return null;
        LocalDate due = reminderDay.plusDays(e.advanceDays);
        if (e.startDate != null && !e.startDate.isEmpty()) {
            try { if (due.isBefore(LocalDate.parse(e.startDate))) return null; }
            catch (Exception ignored) { return null; }
        }
        if (e.repeatType == 0) return due.toString().equals(e.date) ? due : null;
        if (e.repeatType == 1) return due.getDayOfWeek().getValue() == e.weekday ? due : null;
        if (e.repeatType == 2)
            return due.getDayOfMonth() == Math.min(e.monthDay, due.lengthOfMonth()) ? due : null;
        return null;
    }
}
