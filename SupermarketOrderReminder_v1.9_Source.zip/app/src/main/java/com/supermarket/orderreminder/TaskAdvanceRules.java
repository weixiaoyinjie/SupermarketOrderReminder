package com.supermarket.orderreminder;

import java.time.LocalDate;

/** Pure date logic, isolated for testing without the Android SDK. */
public final class TaskAdvanceRules {
    private TaskAdvanceRules() { }

    public static boolean occursOn(Entry e, LocalDate date) {
        if (e.repeatType == 0) return date.toString().equals(e.date);
        if (e.repeatType == 1) return date.getDayOfWeek().getValue() == e.weekday;
        if (e.repeatType == 2) return date.getDayOfMonth() == Math.min(e.monthDay, date.lengthOfMonth());
        if (e.repeatType == 4) return WeekdayRules.includes(e.allowedWeekdays, date)
                && (e.startDate == null || e.startDate.isEmpty() || e.startDate.compareTo(date.toString()) <= 0);
        return false;
    }

    /** N calendar days prior, not N working days prior. */
    public static boolean alertDaysAhead(Entry e, LocalDate viewDate) {
        if (e.kind != 1 || e.advanceDays < 1 || e.advanceDays > 365) return false;
        LocalDate due = viewDate.plusDays(e.advanceDays);
        if (!occursOn(e, due)) return false;
        if (e.startDate != null && !e.startDate.isEmpty()) {
            try { if (LocalDate.parse(e.startDate).isAfter(due)) return false; }
            catch (Exception ignored) { return false; }
        }
        return true;
    }
}
