package com.supermarket.orderreminder;

import java.time.LocalDate;
import java.time.ZoneId;

/** Bit 0 = Monday, bit 6 = Sunday. 63 is Mon-Sat, 127 is every day. */
public final class WeekdayRules {
    private WeekdayRules() { }

    public static int bitForIsoDay(int isoWeekday) {
        if (isoWeekday < 1 || isoWeekday > 7) throw new IllegalArgumentException("ISO weekday must be 1..7");
        return 1 << (isoWeekday - 1);
    }

    public static boolean includes(int mask, LocalDate date) {
        return (mask & bitForIsoDay(date.getDayOfWeek().getValue())) != 0;
    }

    /** Next selected calendar day at the chosen local time, strictly in the future. */
    public static LocalDate nextOccurrence(LocalDate earliest, int mask, int reminderMinute, long nowMillis) {
        if ((mask & 127) == 0 || reminderMinute < 0 || reminderMinute >= 1440) return null;
        for (int offset = 0; offset <= 7; offset++) {
            LocalDate candidate = earliest.plusDays(offset);
            if (!includes(mask, candidate)) continue;
            long when = candidate.atStartOfDay().plusMinutes(reminderMinute)
                    .atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
            if (when > nowMillis) return candidate;
        }
        return null;
    }
}
